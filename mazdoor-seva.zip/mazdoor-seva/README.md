# ⚒️ Mazdoor Seva — मज़दूर सेवा
### Construction Worker Wage Dispute Reporting Portal

> Built with the MERN Stack (MongoDB, Express, React, Node.js) by BrainWave

---

## 🎯 Overview

**Mazdoor Seva** is a full-stack web platform that empowers construction workers to report unpaid wages and other labour disputes. It connects workers, NGOs, and the Worker Welfare Board through a structured complaint lifecycle.

---

## 🏗️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, React Router v6, Axios |
| Backend | Node.js, Express.js |
| Database | MongoDB (via Mongoose) |
| Auth | JWT + OTP (workers), Email/Password (NGOs) |
| Styling | Custom CSS with CSS Variables |
| i18n | English, हिंदी, తెలుగు |

---

## 📁 Project Structure

```
mazdoor-seva/
├── backend/
│   ├── models/
│   │   ├── User.js          # Worker & NGO user model
│   │   └── Complaint.js     # Complaint model with timeline
│   ├── routes/
│   │   ├── auth.js          # OTP login, NGO register/login
│   │   ├── complaints.js    # All complaint CRUD + NGO workflow
│   │   ├── worker.js        # Worker profile
│   │   └── ngo.js           # NGO profile
│   ├── middleware/
│   │   └── auth.js          # JWT protection & role guards
│   ├── uploads/             # Uploaded files (auto-created)
│   ├── server.js            # Express app entry point
│   ├── .env                 # Environment variables
│   └── package.json
│
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── context/
│   │   │   └── AuthContext.js   # Auth state + Axios instance
│   │   ├── utils/
│   │   │   └── translations.js  # EN / HI / TE translations
│   │   ├── components/common/
│   │   │   ├── Navbar.js
│   │   │   └── ProtectedRoute.js
│   │   ├── pages/
│   │   │   ├── HomePage.js           # Landing page
│   │   │   ├── worker/
│   │   │   │   ├── WorkerLogin.js    # OTP login
│   │   │   │   ├── WorkerDashboard.js
│   │   │   │   ├── RegisterComplaint.js  # 4-step form
│   │   │   │   └── TrackComplaint.js
│   │   │   └── ngo/
│   │   │       ├── NGOLogin.js
│   │   │       ├── NGORegister.js
│   │   │       ├── NGODashboard.js
│   │   │       ├── NGOComplaintDetail.js  # Workflow checklist
│   │   │       └── NGOSubmitComplaint.js
│   │   ├── App.js           # Routes
│   │   ├── index.js
│   │   └── index.css        # Global styles
│   └── package.json
│
├── package.json             # Root scripts
└── README.md
```

---

## ⚙️ Setup & Installation

### Prerequisites
- **Node.js** v18+ ([nodejs.org](https://nodejs.org))
- **MongoDB** running locally OR MongoDB Atlas URI
- **npm** v9+

---

### Step 1 — Clone / Extract the project
```bash
cd mazdoor-seva
```

### Step 2 — Install all dependencies
```bash
npm run install-all
```
Or manually:
```bash
# Root
npm install

# Backend
cd backend && npm install

# Frontend
cd ../frontend && npm install
```

### Step 3 — Configure environment
Edit `backend/.env`:
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/mazdoor-seva
JWT_SECRET=your_secret_key_here
JWT_EXPIRE=7d
NODE_ENV=development
```

> **MongoDB Atlas?** Replace `MONGODB_URI` with your Atlas connection string.

### Step 4 — Start the application

**Option A: Run both together (recommended)**
```bash
npm run dev
```

**Option B: Run separately**
```bash
# Terminal 1 — Backend (port 5000)
npm run start:backend

# Terminal 2 — Frontend (port 3000)
npm run start:frontend
```

### Step 5 — Open in browser
```
http://localhost:3000
```

---

## 🚀 Features

### 🔐 Authentication
| User Type | Method |
|-----------|--------|
| Worker | Phone number + 6-digit OTP |
| NGO | Email + Password |

> **Demo Mode:** OTP is returned in the API response (shown in the UI). In production, integrate an SMS provider like Twilio or MSG91.

---

### 👷 Worker Features
- **OTP-based login** via phone number
- **Aadhaar Verification** (simulated for prototype)
- **Anonymous reporting** option (hides identity from contractor)
- **4-step complaint registration form:**
  1. Aadhaar Verification
  2. Work & Contractor Details
  3. Problem Details
  4. Review & Submit
- **Complaint ID generation** on submission
- **SMS confirmation** (logged to console in demo mode)
- **Track complaint** by Complaint ID with progress tracker
- **My Complaints** dashboard with status & timeline

### 🏛️ NGO Features
- Organization registration with document upload
- **Complaint Dashboard** with live stats
- Filter complaints by status & priority
- **Complaint Detail View** with:
  - Worker & Contractor details
  - Contractor flag count (previous complaints)
  - Accept / Decline with confirmation
- **4-step NGO Workflow Checklist:**
  1. Inform Contractor
  2. Contractor Response (Responded / No Response)
  3. Escalate to Worker Welfare Board
  4. Mark Resolved
- Submit complaints **on behalf of workers**
- Internal notes per complaint
- Priority management (High / Medium / Low)

### 📊 Complaint Statuses
```
submitted → under_review → investigation → worker_welfare → resolved
                                      ↘ declined
```

---

## 🌐 Language Support
- **English** (EN)
- **Hindi** (हिंदी)
- **Telugu** (తెలుగు)

Language switcher available on all pages.

---

## 📡 API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/worker/send-otp` | Send OTP to worker phone |
| POST | `/api/auth/worker/verify-otp` | Verify OTP & login |
| POST | `/api/auth/ngo/register` | Register NGO |
| POST | `/api/auth/ngo/login` | NGO login |
| GET | `/api/auth/me` | Get current user |

### Complaints
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/complaints/track/:id` | Public complaint tracking |
| POST | `/api/complaints` | Submit new complaint (worker) |
| GET | `/api/complaints/my` | Worker's own complaints |
| GET | `/api/complaints/ngo/all` | All complaints (NGO) |
| GET | `/api/complaints/ngo/:id` | Complaint detail (NGO) |
| PATCH | `/api/complaints/ngo/:id/accept` | Accept complaint |
| PATCH | `/api/complaints/ngo/:id/decline` | Decline complaint |
| PATCH | `/api/complaints/ngo/:id/workflow` | Update workflow step |
| POST | `/api/complaints/ngo/submit` | NGO submits for worker |
| GET | `/api/complaints/ngo/stats/summary` | Dashboard stats |

---

## 🔧 Production Notes

1. **SMS Integration**: Replace the demo OTP console.log in `backend/routes/auth.js` with a real SMS provider:
   ```js
   // Example with Twilio
   await twilioClient.messages.create({ to: phone, body: `Your OTP: ${otp}` });
   ```

2. **Aadhaar Verification**: Replace the simulated verify button with the actual Aadhaar API or DigiLocker integration.

3. **File Upload Storage**: Move from local `uploads/` to AWS S3 or Cloudinary for production.

4. **CORS**: Update `server.js` CORS origin for your production domain.

5. **HTTPS**: Use a reverse proxy (Nginx) with SSL certificates.

---

## 👥 Team
**BrainWave** — Student Team | Mazdoor Seva Prototype v1.0

---

*Built to protect the rights of India's construction workers* 🇮🇳
