const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    role: {
      type: String,
      enum: ['worker', 'ngo'],
      required: true,
    },

    // Worker fields
    phone: {
      type: String,
      sparse: true,
      trim: true,
    },
    name: { type: String, trim: true },
    aadhaar: { type: String, sparse: true },

    // NGO fields
    ngoName: { type: String, trim: true },
    ngoEmail: { type: String, lowercase: true, trim: true, sparse: true },
    ngoPhone: { type: String, trim: true },
    ngoAddress: { type: String },
    ngoRegNumber: { type: String },
    ngoDocument: { type: String }, // file path
    password: { type: String },

    // Status
    isVerified: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    otp: { type: String },
    otpExpiry: { type: Date },
    preferredLanguage: { type: String, default: 'en' },
  },
  { timestamps: true }
);

// Hash password before save (NGO)
userSchema.pre('save', async function (next) {
  if (!this.isModified('password') || !this.password) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

userSchema.methods.comparePassword = async function (password) {
  return bcrypt.compare(password, this.password);
};

module.exports = mongoose.model('User', userSchema);
