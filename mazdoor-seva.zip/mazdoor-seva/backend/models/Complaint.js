const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const timelineSchema = new mongoose.Schema({
  stage: String,
  date: { type: Date, default: Date.now },
  note: String,
});

const complaintSchema = new mongoose.Schema(
  {
    complaintId: {
      type: String,
      unique: true,
      default: () => 'MS-' + Math.random().toString(36).substr(2, 8).toUpperCase(),
    },
    worker: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    submittedByNGO: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    assignedNGO: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },

    // Worker info snapshot
    workerName: String,
    workerPhone: String,
    workerAadhaar: String,
    isAnonymous: { type: Boolean, default: false },

    // Work details
    workLocation: { type: String, required: true },
    contractorName: { type: String, required: true },
    contractorPhone: String,
    contractorAddress: String,
    typeOfWork: String,
    datesWorked: {
      from: Date,
      to: Date,
    },
    salaryAmount: Number,
    typeOfProblem: {
      type: String,
      enum: ['unpaid_wages', 'partial_payment', 'illegal_deduction', 'overtime_unpaid', 'other'],
      default: 'unpaid_wages',
    },
    description: String,

    // Status
    status: {
      type: String,
      enum: ['submitted', 'under_review', 'investigation', 'worker_welfare', 'resolved', 'declined'],
      default: 'submitted',
    },

    // NGO workflow checklist
    ngoWorkflow: {
      contractorInformed: { type: Boolean, default: false },
      contractorInformedDate: Date,
      contractorResponse: {
        type: String,
        enum: ['pending', 'responded', 'no_response'],
        default: 'pending',
      },
      contractorResponseDate: Date,
      escalatedToWelfare: { type: Boolean, default: false },
      escalatedDate: Date,
      ngoProofDocuments: [String],
      ngoNotes: String,
    },

    // Contractor flag (previous complaints)
    contractorFlagCount: { type: Number, default: 0 },

    // Timeline
    timeline: [timelineSchema],

    // Priority (for NGO sorting)
    priority: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },

    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// Add timeline entry automatically on status change
complaintSchema.pre('save', function (next) {
  if (this.isModified('status')) {
    const stageLabels = {
      submitted: 'Complaint Submitted',
      under_review: 'Under Review',
      investigation: 'Investigation Started',
      worker_welfare: 'Referred to Worker Welfare Board',
      resolved: 'Resolved',
      declined: 'Declined by NGO',
    };
    this.timeline.push({
      stage: stageLabels[this.status] || this.status,
      date: new Date(),
    });
  }
  next();
});

module.exports = mongoose.model('Complaint', complaintSchema);
