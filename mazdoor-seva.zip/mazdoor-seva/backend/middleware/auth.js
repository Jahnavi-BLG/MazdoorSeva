const jwt = require('jsonwebtoken');
const User = require('../models/User');

exports.protect = async (req, res, next) => {
  let token;
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }
  if (!token) {
    return res.status(401).json({ success: false, message: 'Not authorized, no token' });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id).select('-password -otp');
    if (!req.user) return res.status(401).json({ success: false, message: 'User not found' });
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Token invalid or expired' });
  }
};

exports.workerOnly = (req, res, next) => {
  if (req.user.role !== 'worker') {
    return res.status(403).json({ success: false, message: 'Access denied: workers only' });
  }
  next();
};

exports.ngoOnly = (req, res, next) => {
  if (req.user.role !== 'ngo') {
    return res.status(403).json({ success: false, message: 'Access denied: NGOs only' });
  }
  next();
};
