const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Configure multer for NGO document uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '../uploads/ngo-docs');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname.replace(/\s/g, '_'));
  },
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

const generateToken = (userId) =>
  jwt.sign({ id: userId }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE || '7d' });

const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// ─── WORKER: Send OTP ───────────────────────────────────────────────────────
router.post('/worker/send-otp', async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ success: false, message: 'Phone number required' });

    let user = await User.findOne({ phone, role: 'worker' });
    const otp = generateOTP();
    const otpExpiry = new Date(Date.now() + 10 * 60 * 1000); // 10 mins

    if (!user) {
      user = new User({ phone, role: 'worker', otp, otpExpiry });
    } else {
      user.otp = otp;
      user.otpExpiry = otpExpiry;
    }
    await user.save();

    // In production, send SMS. For demo, return OTP in response.
    console.log(`📱 OTP for ${phone}: ${otp}`);
    res.json({ success: true, message: 'OTP sent successfully', otp_demo: otp });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── WORKER: Verify OTP / Login ────────────────────────────────────────────
router.post('/worker/verify-otp', async (req, res) => {
  try {
    const { phone, otp, name } = req.body;
    const user = await User.findOne({ phone, role: 'worker' });

    if (!user) return res.status(404).json({ success: false, message: 'User not found. Please register.' });
    if (user.otp !== otp) return res.status(400).json({ success: false, message: 'Invalid OTP' });
    if (user.otpExpiry < new Date()) return res.status(400).json({ success: false, message: 'OTP expired' });

    user.otp = undefined;
    user.otpExpiry = undefined;
    user.isVerified = true;
    if (name && !user.name) user.name = name;
    await user.save();

    const token = generateToken(user._id);
    res.json({
      success: true,
      token,
      user: { id: user._id, name: user.name, phone: user.phone, role: user.role },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── NGO: Register ─────────────────────────────────────────────────────────
router.post('/ngo/register', upload.single('ngoDocument'), async (req, res) => {
  try {
    const { ngoName, ngoEmail, ngoPhone, ngoAddress, ngoRegNumber, password } = req.body;

    if (!ngoName || !ngoEmail || !password)
      return res.status(400).json({ success: false, message: 'NGO name, email, and password are required' });

    const existing = await User.findOne({ ngoEmail, role: 'ngo' });
    if (existing) return res.status(400).json({ success: false, message: 'NGO already registered with this email' });

    const user = new User({
      role: 'ngo',
      ngoName,
      ngoEmail,
      ngoPhone,
      ngoAddress,
      ngoRegNumber,
      password,
      ngoDocument: req.file ? `/uploads/ngo-docs/${req.file.filename}` : null,
      isVerified: true, // Auto-verify for prototype
    });
    await user.save();

    const token = generateToken(user._id);
    res.status(201).json({
      success: true,
      token,
      user: { id: user._id, ngoName: user.ngoName, ngoEmail: user.ngoEmail, role: user.role },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── NGO: Login ────────────────────────────────────────────────────────────
router.post('/ngo/login', async (req, res) => {
  try {
    const { ngoEmail, password } = req.body;
    if (!ngoEmail || !password)
      return res.status(400).json({ success: false, message: 'Email and password required' });

    const user = await User.findOne({ ngoEmail, role: 'ngo' });
    if (!user) return res.status(404).json({ success: false, message: 'NGO not found. Please register.' });

    const isMatch = await user.comparePassword(password);
    if (!isMatch) return res.status(401).json({ success: false, message: 'Invalid credentials' });

    const token = generateToken(user._id);
    res.json({
      success: true,
      token,
      user: { id: user._id, ngoName: user.ngoName, ngoEmail: user.ngoEmail, role: user.role },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── GET current user ──────────────────────────────────────────────────────
const { protect } = require('../middleware/auth');
router.get('/me', protect, async (req, res) => {
  res.json({ success: true, user: req.user });
});

module.exports = router;
