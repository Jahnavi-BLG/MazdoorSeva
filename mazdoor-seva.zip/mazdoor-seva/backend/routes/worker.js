const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { protect, workerOnly } = require('../middleware/auth');

router.get('/profile', protect, workerOnly, async (req, res) => {
  res.json({ success: true, user: req.user });
});

router.patch('/profile', protect, workerOnly, async (req, res) => {
  try {
    const { name, preferredLanguage } = req.body;
    if (name) req.user.name = name;
    if (preferredLanguage) req.user.preferredLanguage = preferredLanguage;
    await req.user.save();
    res.json({ success: true, user: req.user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
