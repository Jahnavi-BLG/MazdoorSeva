const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { protect, ngoOnly } = require('../middleware/auth');

router.get('/profile', protect, ngoOnly, async (req, res) => {
  res.json({ success: true, user: req.user });
});

router.patch('/profile', protect, ngoOnly, async (req, res) => {
  try {
    const allowed = ['ngoName', 'ngoPhone', 'ngoAddress', 'preferredLanguage'];
    allowed.forEach(field => {
      if (req.body[field] !== undefined) req.user[field] = req.body[field];
    });
    await req.user.save();
    res.json({ success: true, user: req.user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
