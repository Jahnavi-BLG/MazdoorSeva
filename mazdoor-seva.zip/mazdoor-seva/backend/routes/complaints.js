const express = require('express');
const router = express.Router();
const Complaint = require('../models/Complaint');
const { protect, workerOnly, ngoOnly } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '../uploads/complaint-docs');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname.replace(/\s/g, '_'));
  },
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

// ─── PUBLIC: Track complaint by ID ─────────────────────────────────────────
router.get('/track/:complaintId', async (req, res) => {
  try {
    const complaint = await Complaint.findOne({ complaintId: req.params.complaintId });
    if (!complaint) return res.status(404).json({ success: false, message: 'Complaint not found' });

    // Return limited info for public tracking
    res.json({
      success: true,
      complaint: {
        complaintId: complaint.complaintId,
        status: complaint.status,
        workLocation: complaint.workLocation,
        typeOfProblem: complaint.typeOfProblem,
        timeline: complaint.timeline,
        createdAt: complaint.createdAt,
        updatedAt: complaint.updatedAt,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── WORKER: Submit complaint ───────────────────────────────────────────────
router.post('/', protect, workerOnly, upload.none(), async (req, res) => {
  try {
    const {
      workLocation, contractorName, contractorPhone, contractorAddress,
      typeOfWork, dateFrom, dateTo, salaryAmount, typeOfProblem,
      description, isAnonymous, aadhaar,
    } = req.body;

    if (!workLocation || !contractorName)
      return res.status(400).json({ success: false, message: 'Work location and contractor name are required' });

    // Count previous complaints against this contractor
    const flagCount = await Complaint.countDocuments({ contractorName, status: { $ne: 'declined' } });

    const complaint = new Complaint({
      worker: req.user._id,
      workerName: req.user.name,
      workerPhone: req.user.phone,
      workerAadhaar: aadhaar,
      isAnonymous: isAnonymous === 'true' || isAnonymous === true,
      workLocation,
      contractorName,
      contractorPhone,
      contractorAddress,
      typeOfWork,
      datesWorked: { from: dateFrom, to: dateTo },
      salaryAmount,
      typeOfProblem,
      description,
      contractorFlagCount: flagCount,
      status: 'submitted',
    });

    await complaint.save();

    res.status(201).json({
      success: true,
      message: 'Complaint submitted successfully!',
      complaintId: complaint.complaintId,
      complaint,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── WORKER: My complaints ──────────────────────────────────────────────────
router.get('/my', protect, workerOnly, async (req, res) => {
  try {
    const complaints = await Complaint.find({ worker: req.user._id })
      .sort({ createdAt: -1 });
    res.json({ success: true, complaints });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── NGO: Get all complaints (dashboard) ───────────────────────────────────
router.get('/ngo/all', protect, ngoOnly, async (req, res) => {
  try {
    const { status, priority, page = 1, limit = 20 } = req.query;
    const filter = { isActive: true };
    if (status) filter.status = status;
    if (priority) filter.priority = priority;

    const complaints = await Complaint.find(filter)
      .sort({ priority: -1, createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .populate('worker', 'name phone')
      .populate('assignedNGO', 'ngoName');

    const total = await Complaint.countDocuments(filter);
    res.json({ success: true, complaints, total, pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── NGO: Get complaint details ─────────────────────────────────────────────
router.get('/ngo/:id', protect, ngoOnly, async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id)
      .populate('worker', 'name phone aadhaar')
      .populate('assignedNGO', 'ngoName ngoEmail ngoPhone');
    if (!complaint) return res.status(404).json({ success: false, message: 'Complaint not found' });
    res.json({ success: true, complaint });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── NGO: Accept complaint ──────────────────────────────────────────────────
router.patch('/ngo/:id/accept', protect, ngoOnly, async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id);
    if (!complaint) return res.status(404).json({ success: false, message: 'Complaint not found' });

    complaint.assignedNGO = req.user._id;
    complaint.status = 'under_review';
    complaint.priority = req.body.priority || complaint.priority;
    await complaint.save();

    res.json({ success: true, message: 'Complaint accepted', complaint });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── NGO: Decline complaint ─────────────────────────────────────────────────
router.patch('/ngo/:id/decline', protect, ngoOnly, async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id);
    if (!complaint) return res.status(404).json({ success: false, message: 'Complaint not found' });

    complaint.status = 'declined';
    complaint.isActive = false;
    await complaint.save();

    res.json({ success: true, message: 'Complaint declined', complaint });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── NGO: Update workflow checklist ────────────────────────────────────────
router.patch('/ngo/:id/workflow', protect, ngoOnly, async (req, res) => {
  try {
    const { step, value, notes } = req.body;
    const complaint = await Complaint.findById(req.params.id);
    if (!complaint) return res.status(404).json({ success: false, message: 'Complaint not found' });

    if (step === 'inform_contractor') {
      complaint.ngoWorkflow.contractorInformed = true;
      complaint.ngoWorkflow.contractorInformedDate = new Date();
      complaint.status = 'under_review';
    } else if (step === 'contractor_response') {
      complaint.ngoWorkflow.contractorResponse = value; // 'responded' or 'no_response'
      complaint.ngoWorkflow.contractorResponseDate = new Date();
      if (value === 'responded') {
        complaint.status = 'under_review';
      }
    } else if (step === 'escalate_welfare') {
      complaint.ngoWorkflow.escalatedToWelfare = true;
      complaint.ngoWorkflow.escalatedDate = new Date();
      complaint.status = 'worker_welfare';
    } else if (step === 'resolve') {
      complaint.status = 'resolved';
    } else if (step === 'priority') {
      complaint.priority = value;
    }

    if (notes) complaint.ngoWorkflow.ngoNotes = notes;
    await complaint.save();

    res.json({ success: true, message: 'Workflow updated', complaint });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── NGO: Submit complaint on behalf of worker ─────────────────────────────
router.post('/ngo/submit', protect, ngoOnly, upload.array('proofDocuments', 5), async (req, res) => {
  try {
    const {
      workerName, workerPhone, workerAadhaar,
      workLocation, contractorName, contractorPhone, contractorAddress,
      typeOfWork, dateFrom, dateTo, salaryAmount, typeOfProblem, description,
    } = req.body;

    const flagCount = await Complaint.countDocuments({ contractorName, status: { $ne: 'declined' } });

    const proofDocs = req.files ? req.files.map(f => `/uploads/complaint-docs/${f.filename}`) : [];

    const complaint = new Complaint({
      submittedByNGO: req.user._id,
      assignedNGO: req.user._id,
      workerName,
      workerPhone,
      workerAadhaar,
      workLocation,
      contractorName,
      contractorPhone,
      contractorAddress,
      typeOfWork,
      datesWorked: { from: dateFrom, to: dateTo },
      salaryAmount,
      typeOfProblem,
      description,
      contractorFlagCount: flagCount,
      status: 'under_review',
      ngoWorkflow: { ngoProofDocuments: proofDocs },
    });

    await complaint.save();
    res.status(201).json({ success: true, message: 'Complaint submitted on behalf of worker', complaintId: complaint.complaintId, complaint });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── NGO: Stats ────────────────────────────────────────────────────────────
router.get('/ngo/stats/summary', protect, ngoOnly, async (req, res) => {
  try {
    const [total, submitted, under_review, investigation, worker_welfare, resolved, declined] = await Promise.all([
      Complaint.countDocuments({ isActive: true }),
      Complaint.countDocuments({ status: 'submitted' }),
      Complaint.countDocuments({ status: 'under_review' }),
      Complaint.countDocuments({ status: 'investigation' }),
      Complaint.countDocuments({ status: 'worker_welfare' }),
      Complaint.countDocuments({ status: 'resolved' }),
      Complaint.countDocuments({ status: 'declined' }),
    ]);
    res.json({ success: true, stats: { total, submitted, under_review, investigation, worker_welfare, resolved, declined } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
