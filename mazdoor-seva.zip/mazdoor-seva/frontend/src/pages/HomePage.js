import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';

const languages = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'हिंदी' },
  { code: 'te', label: 'తెలుగు' },
];

export default function HomePage() {
  const navigate = useNavigate();
  const { language, changeLanguage } = useAuth();
  const { t } = useTranslation(language);

  return (
    <div className="page" style={{ background: 'linear-gradient(135deg, #1a56db 0%, #0f3a8c 60%, #1e1b4b 100%)', minHeight: '100vh' }}>
      {/* Header Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem 2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', color: '#fff' }}>
          <div style={{ width: 42, height: 42, background: 'rgba(255,255,255,.2)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.4rem' }}>⚒️</div>
          <div>
            <div style={{ fontWeight: 800, fontSize: '1.2rem', letterSpacing: '.01em' }}>{t('appName')}</div>
            <div style={{ fontSize: '.7rem', opacity: .7, letterSpacing: '.06em', textTransform: 'uppercase' }}>{t('tagline')}</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '.4rem' }}>
          {languages.map(l => (
            <button key={l.code} onClick={() => changeLanguage(l.code)} style={{
              padding: '.35rem .8rem', borderRadius: 8, border: language === l.code ? '2px solid #fff' : '2px solid rgba(255,255,255,.3)',
              background: language === l.code ? 'rgba(255,255,255,.25)' : 'transparent',
              color: '#fff', fontWeight: 700, fontSize: '.8rem', cursor: 'pointer', transition: 'all .15s'
            }}>
              {l.label}
            </button>
          ))}
        </div>
      </div>

      {/* Hero Section */}
      <div style={{ textAlign: 'center', padding: '3rem 2rem 2rem', color: '#fff' }}>
        <div style={{ display: 'inline-block', background: 'rgba(255,255,255,.15)', border: '1px solid rgba(255,255,255,.3)', borderRadius: 999, padding: '.4rem 1.2rem', fontSize: '.85rem', fontWeight: 600, marginBottom: '1.5rem', backdropFilter: 'blur(8px)' }}>
          🇮🇳 Government Worker Welfare Initiative
        </div>
        <h1 style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 900, lineHeight: 1.15, marginBottom: '1rem', letterSpacing: '-.02em' }}>
          {language === 'hi' ? 'अपने हक के लिए आवाज़ उठाएं' : language === 'te' ? 'మీ హక్కుల కోసం నిలబడండి' : 'Stand Up for Your Rights'}
        </h1>
        <p style={{ fontSize: '1.15rem', opacity: .85, maxWidth: 560, margin: '0 auto 2.5rem', lineHeight: 1.7 }}>
          {language === 'hi'
            ? 'निर्माण श्रमिकों के लिए मुफ्त ऑनलाइन शिकायत प्रणाली। बकाया वेतन, अन्याय के खिलाफ लड़ें।'
            : language === 'te'
            ? 'నిర్మాణ కార్మికులకు ఉచిత ఆన్‌లైన్ ఫిర్యాదు వ్యవస్థ. బకాయి వేతనాల కోసం పోరాడండి.'
            : 'Free online complaint system for construction workers. Fight against unpaid wages and exploitation.'}
        </p>

        {/* CTA Cards */}
        <div style={{ display: 'flex', gap: '1.5rem', justifyContent: 'center', flexWrap: 'wrap', maxWidth: 700, margin: '0 auto' }}>
          {/* Worker Card */}
          <div style={{ background: 'rgba(255,255,255,.12)', backdropFilter: 'blur(12px)', border: '1px solid rgba(255,255,255,.25)', borderRadius: 20, padding: '2rem', flex: '1', minWidth: 260, maxWidth: 300, transition: 'all .2s' }}
            onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,.2)'}
            onMouseLeave={e => e.currentTarget.style.background = 'rgba(255,255,255,.12)'}
          >
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>👷</div>
            <h2 style={{ fontSize: '1.3rem', fontWeight: 800, marginBottom: '.5rem', color: '#fff' }}>
              {language === 'hi' ? 'मज़दूर' : language === 'te' ? 'కార్మికుడు' : 'Worker'}
            </h2>
            <p style={{ fontSize: '.9rem', opacity: .8, marginBottom: '1.5rem', lineHeight: 1.6 }}>
              {language === 'hi' ? 'शिकायत दर्ज करें और ट्रैक करें' : language === 'te' ? 'ఫిర్యాదు నమోదు చేయండి మరియు ట్రాక్ చేయండి' : 'Register and track your wage complaint'}
            </p>
            <button className="btn btn-lg btn-full" onClick={() => navigate('/worker/login')}
              style={{ background: '#fff', color: 'var(--primary)', fontWeight: 800, marginBottom: '.75rem' }}>
              {t('loginAsWorker')}
            </button>
            <button className="btn btn-lg btn-full" onClick={() => navigate('/worker/login')}
              style={{ background: 'transparent', color: '#fff', border: '2px solid rgba(255,255,255,.5)', fontWeight: 700 }}>
              {language === 'hi' ? 'नया पंजीकरण' : language === 'te' ? 'కొత్త నమోదు' : 'New Registration'}
            </button>
          </div>

          {/* NGO Card */}
          <div style={{ background: 'rgba(249,115,22,.15)', backdropFilter: 'blur(12px)', border: '1px solid rgba(249,115,22,.4)', borderRadius: 20, padding: '2rem', flex: '1', minWidth: 260, maxWidth: 300, transition: 'all .2s' }}
            onMouseEnter={e => e.currentTarget.style.background = 'rgba(249,115,22,.25)'}
            onMouseLeave={e => e.currentTarget.style.background = 'rgba(249,115,22,.15)'}
          >
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🏛️</div>
            <h2 style={{ fontSize: '1.3rem', fontWeight: 800, marginBottom: '.5rem', color: '#fff' }}>
              {language === 'hi' ? 'NGO / संगठन' : language === 'te' ? 'NGO / సంస్థ' : 'NGO / Organisation'}
            </h2>
            <p style={{ fontSize: '.9rem', opacity: .8, marginBottom: '1.5rem', lineHeight: 1.6 }}>
              {language === 'hi' ? 'शिकायतें प्रबंधित करें और श्रमिकों की मदद करें' : language === 'te' ? 'ఫిర్యాదులు నిర్వహించండి మరియు కార్మికులకు సహాయం చేయండి' : 'Manage complaints and help workers get justice'}
            </p>
            <button className="btn btn-lg btn-full" onClick={() => navigate('/ngo/login')}
              style={{ background: 'var(--secondary)', color: '#fff', fontWeight: 800, marginBottom: '.75rem' }}>
              {t('loginAsNGO')}
            </button>
            <button className="btn btn-lg btn-full" onClick={() => navigate('/ngo/register')}
              style={{ background: 'transparent', color: '#fff', border: '2px solid rgba(255,255,255,.5)', fontWeight: 700 }}>
              {t('registerAsNGO')}
            </button>
          </div>
        </div>

        {/* Track complaint link */}
        <div style={{ marginTop: '2rem' }}>
          <button onClick={() => navigate('/track')} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,.8)', fontSize: '.95rem', cursor: 'pointer', textDecoration: 'underline', fontFamily: 'inherit' }}>
            🔍 {language === 'hi' ? 'शिकायत ID से स्थिति जांचें' : language === 'te' ? 'ఫిర్యాదు IDతో స్థితి తనిఖీ చేయండి' : 'Check complaint status with Complaint ID'}
          </button>
        </div>
      </div>

      {/* How it works */}
      <div style={{ background: 'rgba(0,0,0,.25)', margin: '2rem 0 0', padding: '2.5rem 2rem' }}>
        <h3 style={{ color: '#fff', textAlign: 'center', fontWeight: 800, fontSize: '1.4rem', marginBottom: '2rem' }}>
          {language === 'hi' ? 'यह कैसे काम करता है' : language === 'te' ? 'ఇది ఎలా పని చేస్తుంది' : 'How It Works'}
        </h3>
        <div style={{ display: 'flex', gap: '1.5rem', justifyContent: 'center', flexWrap: 'wrap', maxWidth: 900, margin: '0 auto' }}>
          {[
            { icon: '📱', step: '1', title: language === 'hi' ? 'OTP से लॉगिन' : 'Login with OTP', desc: language === 'hi' ? 'अपने फ़ोन नंबर से पंजीकरण करें' : 'Register with your phone number' },
            { icon: '📝', step: '2', title: language === 'hi' ? 'शिकायत दर्ज करें' : 'File Complaint', desc: language === 'hi' ? 'आधार और विवरण के साथ फॉर्म भरें' : 'Fill form with Aadhaar & details' },
            { icon: '🔔', step: '3', title: language === 'hi' ? 'SMS पुष्टि' : 'SMS Confirmation', desc: language === 'hi' ? 'Complaint ID और पुष्टि प्राप्त करें' : 'Receive Complaint ID & confirmation' },
            { icon: '⚖️', step: '4', title: language === 'hi' ? 'जांच और समाधान' : 'Investigation & Resolution', desc: language === 'hi' ? 'NGO और कल्याण बोर्ड कार्रवाई करेंगे' : 'NGO & Welfare Board takes action' },
          ].map((item, i) => (
            <div key={i} style={{ textAlign: 'center', color: '#fff', maxWidth: 180 }}>
              <div style={{ fontSize: '2rem', marginBottom: '.5rem' }}>{item.icon}</div>
              <div style={{ width: 28, height: 28, background: 'var(--secondary)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: '.85rem', margin: '0 auto .6rem' }}>{item.step}</div>
              <div style={{ fontWeight: 700, marginBottom: '.3rem', fontSize: '.95rem' }}>{item.title}</div>
              <div style={{ fontSize: '.82rem', opacity: .75, lineHeight: 1.5 }}>{item.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div style={{ textAlign: 'center', padding: '1.5rem', color: 'rgba(255,255,255,.5)', fontSize: '.8rem' }}>
        © 2024 Mazdoor Seva | BrainWave | Built to protect workers' rights
      </div>
    </div>
  );
}
