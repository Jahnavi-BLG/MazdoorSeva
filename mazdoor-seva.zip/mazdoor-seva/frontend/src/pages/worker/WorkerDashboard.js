import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import Navbar from '../../components/common/Navbar';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';

const statusConfig = {
  submitted: { label: 'Submitted', color: 'badge-submitted', icon: '📋', step: 1 },
  under_review: { label: 'Under Review', color: 'badge-under_review', icon: '🔍', step: 2 },
  investigation: { label: 'Investigation', color: 'badge-investigation', icon: '🕵️', step: 3 },
  worker_welfare: { label: 'Worker Welfare', color: 'badge-worker_welfare', icon: '⚖️', step: 4 },
  resolved: { label: 'Resolved', color: 'badge-resolved', icon: '✅', step: 5 },
  declined: { label: 'Declined', color: 'badge-declined', icon: '❌', step: 0 },
};

const statusSteps = ['submitted', 'under_review', 'investigation', 'worker_welfare', 'resolved'];

export default function WorkerDashboard() {
  const { user, language, API } = useAuth();
  const { t } = useTranslation(language);
  const navigate = useNavigate();
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    API.get('/complaints/my')
      .then(res => setComplaints(res.data.complaints))
      .catch(() => toast.error('Failed to load complaints'))
      .finally(() => setLoading(false));
  }, []);

  const formatDate = (d) => d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

  return (
    <div>
      <Navbar />
      <div className="page-header">
        <div className="container">
          <h1>🙏 {t('welcomeWorker')}, {user?.name || user?.phone}!</h1>
          <p>{language === 'hi' ? 'आपकी शिकायतें और उनकी स्थिति यहाँ देखें' : language === 'te' ? 'మీ ఫిర్యాదులు మరియు వాటి స్థితిని ఇక్కడ చూడండి' : 'View your complaints and their current status'}</p>
        </div>
      </div>

      <div className="container" style={{ padding: '2rem 1.5rem' }}>
        {/* Action Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
          <div onClick={() => navigate('/worker/register-complaint')}
            style={{ background: 'linear-gradient(135deg, var(--primary), var(--primary-dark))', color: '#fff', borderRadius: 16, padding: '1.5rem', cursor: 'pointer', transition: 'all .2s', boxShadow: '0 4px 20px rgba(26,86,219,.3)' }}
            onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-3px)'}
            onMouseLeave={e => e.currentTarget.style.transform = 'none'}>
            <div style={{ fontSize: '2rem', marginBottom: '.75rem' }}>📝</div>
            <div style={{ fontWeight: 800, fontSize: '1.1rem', marginBottom: '.25rem' }}>{t('registerComplaint')}</div>
            <div style={{ opacity: .85, fontSize: '.85rem' }}>{language === 'hi' ? 'नई शिकायत दर्ज करें' : 'File a new wage complaint'}</div>
          </div>
          <div onClick={() => navigate('/worker/track')}
            style={{ background: 'linear-gradient(135deg, var(--secondary), var(--secondary-dark))', color: '#fff', borderRadius: 16, padding: '1.5rem', cursor: 'pointer', transition: 'all .2s', boxShadow: '0 4px 20px rgba(249,115,22,.3)' }}
            onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-3px)'}
            onMouseLeave={e => e.currentTarget.style.transform = 'none'}>
            <div style={{ fontSize: '2rem', marginBottom: '.75rem' }}>🔍</div>
            <div style={{ fontWeight: 800, fontSize: '1.1rem', marginBottom: '.25rem' }}>{t('trackComplaint')}</div>
            <div style={{ opacity: .85, fontSize: '.85rem' }}>{language === 'hi' ? 'Complaint ID से स्थिति जांचें' : 'Check status by Complaint ID'}</div>
          </div>
          <div style={{ background: 'linear-gradient(135deg, #059669, #047857)', color: '#fff', borderRadius: 16, padding: '1.5rem', cursor: 'default' }}>
            <div style={{ fontSize: '2rem', marginBottom: '.75rem' }}>📊</div>
            <div style={{ fontWeight: 800, fontSize: '1.75rem', lineHeight: 1 }}>{complaints.length}</div>
            <div style={{ opacity: .85, fontSize: '.9rem', marginTop: '.25rem' }}>{t('myComplaints')}</div>
          </div>
        </div>

        {/* Complaints List */}
        <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 1fr' : '1fr', gap: '1.5rem' }}>
          <div>
            <h2 style={{ fontWeight: 800, fontSize: '1.2rem', marginBottom: '1rem', color: 'var(--gray-800)' }}>{t('myComplaints')}</h2>
            {loading ? (
              <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--gray-400)' }}>
                <div className="spinner spinner-dark" style={{ width: 32, height: 32, margin: '0 auto 1rem' }} />
                <p>{t('loadingComplaints')}</p>
              </div>
            ) : complaints.length === 0 ? (
              <div className="card" style={{ padding: '3rem', textAlign: 'center' }}>
                <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📭</div>
                <p style={{ color: 'var(--gray-500)', marginBottom: '1rem' }}>{t('noComplaintsFound')}</p>
                <button className="btn btn-primary" onClick={() => navigate('/worker/register-complaint')}>{t('registerComplaint')}</button>
              </div>
            ) : (
              complaints.map(c => {
                const sc = statusConfig[c.status] || statusConfig.submitted;
                return (
                  <div key={c._id} className="complaint-card" onClick={() => setSelected(selected?._id === c._id ? null : c)}
                    style={{ borderColor: selected?._id === c._id ? 'var(--primary)' : undefined, boxShadow: selected?._id === c._id ? '0 0 0 2px var(--primary)' : undefined }}>
                    <div className="complaint-card-header">
                      <span className="complaint-id">🆔 {c.complaintId}</span>
                      <span className={`badge ${sc.color}`}>{sc.icon} {sc.label}</span>
                    </div>
                    <div style={{ fontWeight: 700, marginBottom: '.5rem', color: 'var(--gray-800)' }}>{c.workLocation}</div>
                    <div className="complaint-meta">
                      <span className="complaint-meta-item">🏗️ {c.contractorName}</span>
                      <span className="complaint-meta-item">📅 {formatDate(c.createdAt)}</span>
                      {c.salaryAmount && <span className="complaint-meta-item">💰 ₹{c.salaryAmount?.toLocaleString()}</span>}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Detail Panel */}
          {selected && (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <h2 style={{ fontWeight: 800, fontSize: '1.2rem', color: 'var(--gray-800)' }}>{t('complaintDetails')}</h2>
                <button className="btn btn-ghost btn-sm" onClick={() => setSelected(null)}>✕ Close</button>
              </div>
              <ComplaintDetail complaint={selected} t={t} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ComplaintDetail({ complaint: c, t }) {
  const statusStepMap = { submitted: 0, under_review: 1, investigation: 2, worker_welfare: 3, resolved: 4 };
  const currentStep = statusStepMap[c.status] ?? 0;
  const steps = [
    { key: 'submitted', label: 'Submitted', icon: '📋' },
    { key: 'under_review', label: 'Under Review', icon: '🔍' },
    { key: 'investigation', label: 'Investigation', icon: '🕵️' },
    { key: 'worker_welfare', label: 'Worker Welfare', icon: '⚖️' },
    { key: 'resolved', label: 'Resolved', icon: '✅' },
  ];

  return (
    <div className="card" style={{ boxShadow: 'var(--shadow)' }}>
      <div className="card-body">
        {/* Complaint ID Badge */}
        <div style={{ background: 'var(--primary-light)', border: '1px solid var(--primary)', borderRadius: 8, padding: '.75rem 1rem', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontWeight: 700, color: 'var(--primary)', fontSize: '.9rem' }}>🆔 {t('complaintId')}</span>
          <span style={{ fontWeight: 900, fontSize: '1.1rem', color: 'var(--primary-dark)', letterSpacing: '.05em' }}>{c.complaintId}</span>
        </div>

        {/* Progress Steps */}
        {c.status !== 'declined' && (
          <div style={{ marginBottom: '1.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', position: 'relative', padding: '0 1rem' }}>
              <div style={{ position: 'absolute', top: 16, left: '10%', right: '10%', height: 3, background: 'var(--gray-200)', zIndex: 0, borderRadius: 2 }}>
                <div style={{ height: '100%', background: 'var(--primary)', borderRadius: 2, width: `${(currentStep / 4) * 100}%`, transition: 'width .5s ease' }} />
              </div>
              {steps.map((s, i) => (
                <div key={s.key} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', zIndex: 1, minWidth: 40 }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '.85rem',
                    background: i <= currentStep ? 'var(--primary)' : '#fff',
                    border: `2px solid ${i <= currentStep ? 'var(--primary)' : 'var(--gray-300)'}`,
                    color: i <= currentStep ? '#fff' : 'var(--gray-400)',
                    transition: 'all .3s',
                  }}>
                    {i < currentStep ? '✓' : s.icon}
                  </div>
                  <div style={{ fontSize: '.65rem', color: i <= currentStep ? 'var(--primary)' : 'var(--gray-400)', marginTop: '.3rem', textAlign: 'center', fontWeight: i === currentStep ? 700 : 400, maxWidth: 50 }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Details */}
        <div style={{ display: 'grid', gap: '.75rem' }}>
          {[
            { label: t('workLocation'), value: c.workLocation, icon: '📍' },
            { label: t('contractorName'), value: c.contractorName, icon: '👤' },
            { label: t('typeOfWork'), value: c.typeOfWork, icon: '🔧' },
            { label: t('salaryAmount'), value: c.salaryAmount ? `₹${c.salaryAmount.toLocaleString()}` : null, icon: '💰' },
            { label: 'Submitted', value: new Date(c.createdAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' }), icon: '📅' },
            { label: 'Anonymous', value: c.isAnonymous ? 'Yes – identity hidden from contractor' : 'No', icon: '🔒' },
          ].filter(r => r.value).map((row, i) => (
            <div key={i} style={{ display: 'flex', gap: '.75rem', alignItems: 'flex-start', padding: '.6rem .75rem', background: 'var(--gray-50)', borderRadius: 8 }}>
              <span style={{ fontSize: '1rem', flexShrink: 0 }}>{row.icon}</span>
              <div>
                <div style={{ fontSize: '.75rem', color: 'var(--gray-500)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.04em' }}>{row.label}</div>
                <div style={{ fontWeight: 600, color: 'var(--gray-800)', fontSize: '.9rem' }}>{row.value}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Timeline */}
        {c.timeline?.length > 0 && (
          <div style={{ marginTop: '1.25rem' }}>
            <div style={{ fontWeight: 700, fontSize: '.9rem', color: 'var(--gray-700)', marginBottom: '.75rem' }}>📅 Activity Timeline</div>
            <div className="timeline">
              {c.timeline.map((tl, i) => (
                <div key={i} className={`timeline-item ${i < c.timeline.length - 1 ? 'done' : 'active'}`}>
                  <div className="timeline-label">{tl.stage}</div>
                  <div className="timeline-date">{new Date(tl.date).toLocaleString('en-IN')}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
