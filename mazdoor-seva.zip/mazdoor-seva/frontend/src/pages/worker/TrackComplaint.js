import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import Navbar from '../../components/common/Navbar';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';
import { API } from '../../context/AuthContext';

const statusConfig = {
  submitted: { step: 0, label: 'Submitted', color: '#6b7280', bg: '#f3f4f6', icon: '📋' },
  under_review: { step: 1, label: 'Under Review', color: '#d97706', bg: '#fef3c7', icon: '🔍' },
  investigation: { step: 2, label: 'Investigation', color: '#0891b2', bg: '#cffafe', icon: '🕵️' },
  worker_welfare: { step: 3, label: 'Worker Welfare Board', color: '#7c3aed', bg: '#ede9fe', icon: '⚖️' },
  resolved: { step: 4, label: 'Resolved', color: '#16a34a', bg: '#dcfce7', icon: '✅' },
  declined: { step: -1, label: 'Declined', color: '#dc2626', bg: '#fee2e2', icon: '❌' },
};

const STEPS = [
  { key: 'submitted', label: 'Submitted', icon: '📋', desc: 'Complaint received in the system' },
  { key: 'under_review', label: 'Under Review', icon: '🔍', desc: 'NGO is reviewing the complaint' },
  { key: 'investigation', label: 'Investigation', icon: '🕵️', desc: 'Investigation in progress' },
  { key: 'worker_welfare', label: 'Worker Welfare', icon: '⚖️', desc: 'Referred to Worker Welfare Board' },
  { key: 'resolved', label: 'Resolved', icon: '✅', desc: 'Issue has been resolved' },
];

export default function TrackComplaint() {
  const [complaintId, setComplaintId] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const { language } = useAuth();
  const { t } = useTranslation(language);
  const navigate = useNavigate();

  const handleTrack = async (e) => {
    e.preventDefault();
    if (!complaintId.trim()) return toast.error('Please enter a Complaint ID');
    setLoading(true);
    setResult(null);
    try {
      const res = await API.get(`/complaints/track/${complaintId.trim().toUpperCase()}`);
      setResult(res.data.complaint);
    } catch (err) {
      if (err.response?.status === 404) toast.error('No complaint found with this ID. Please check and try again.');
      else toast.error('Failed to fetch complaint status');
    } finally {
      setLoading(false);
    }
  };

  const currentSC = result ? statusConfig[result.status] || statusConfig.submitted : null;
  const currentStep = currentSC ? currentSC.step : -1;

  return (
    <div>
      <Navbar />
      <div className="page-header">
        <div className="container">
          <h1>🔍 {t('trackComplaint')}</h1>
          <p>{language === 'hi' ? 'अपनी शिकायत की वर्तमान स्थिति जानें' : 'Check the current status of your complaint'}</p>
        </div>
      </div>

      <div className="container" style={{ padding: '2rem 1.5rem', maxWidth: 680 }}>
        {/* Search Form */}
        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <div className="card-body">
            <form onSubmit={handleTrack}>
              <div className="form-group" style={{ marginBottom: '1rem' }}>
                <label className="form-label" style={{ fontSize: '1rem' }}>🆔 {t('complaintId')}</label>
                <div style={{ display: 'flex', gap: '.75rem' }}>
                  <input
                    className="form-control"
                    placeholder="e.g. MS-A1B2C3D4"
                    value={complaintId}
                    onChange={e => setComplaintId(e.target.value.toUpperCase())}
                    style={{ flex: 1, fontSize: '1.1rem', letterSpacing: '.06em', fontWeight: 600 }}
                  />
                  <button type="submit" className="btn btn-primary btn-lg" disabled={loading} style={{ whiteSpace: 'nowrap' }}>
                    {loading ? <><span className="spinner" /></> : `${t('track')} →`}
                  </button>
                </div>
                <p className="form-hint">You received this ID via SMS when you submitted your complaint</p>
              </div>
            </form>
          </div>
        </div>

        {/* Result */}
        {result && (
          <div className="card" style={{ boxShadow: 'var(--shadow)' }}>
            {/* Status Banner */}
            <div style={{ background: currentSC.bg, borderBottom: `3px solid ${currentSC.color}`, padding: '1.5rem 2rem', display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
              <div style={{ fontSize: '2.5rem' }}>{currentSC.icon}</div>
              <div>
                <div style={{ fontSize: '.8rem', color: 'var(--gray-500)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.06em' }}>Current Status</div>
                <div style={{ fontWeight: 900, fontSize: '1.4rem', color: currentSC.color }}>{currentSC.label}</div>
              </div>
              <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
                <div style={{ fontSize: '.75rem', color: 'var(--gray-500)' }}>Complaint ID</div>
                <div style={{ fontWeight: 900, fontSize: '1.1rem', letterSpacing: '.06em' }}>{result.complaintId}</div>
              </div>
            </div>

            <div className="card-body">
              {/* Progress Steps */}
              {result.status !== 'declined' && (
                <div style={{ marginBottom: '2rem' }}>
                  <div style={{ fontWeight: 700, color: 'var(--gray-700)', marginBottom: '1.25rem', fontSize: '.95rem' }}>📊 Progress Tracker</div>
                  <div style={{ position: 'relative' }}>
                    {/* connector line */}
                    <div style={{ position: 'absolute', top: 20, left: '10%', right: '10%', height: 3, background: 'var(--gray-200)', zIndex: 0 }}>
                      <div style={{ height: '100%', background: 'var(--primary)', width: `${(currentStep / 4) * 100}%`, transition: 'width .5s ease', borderRadius: 2 }} />
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', position: 'relative', zIndex: 1 }}>
                      {STEPS.map((s, i) => (
                        <div key={s.key} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1 }}>
                          <div style={{
                            width: 40, height: 40, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                            fontSize: i <= currentStep ? '1.1rem' : '1rem',
                            background: i < currentStep ? 'var(--primary)' : i === currentStep ? 'var(--primary)' : '#fff',
                            border: `3px solid ${i <= currentStep ? 'var(--primary)' : 'var(--gray-300)'}`,
                            boxShadow: i === currentStep ? '0 0 0 4px rgba(26,86,219,.2)' : 'none',
                            transition: 'all .3s',
                            color: i <= currentStep ? '#fff' : 'var(--gray-400)',
                          }}>
                            {i < currentStep ? '✓' : s.icon}
                          </div>
                          <div style={{ marginTop: '.5rem', textAlign: 'center' }}>
                            <div style={{ fontSize: '.72rem', fontWeight: 700, color: i <= currentStep ? 'var(--primary-dark)' : 'var(--gray-400)' }}>{s.label}</div>
                            <div style={{ fontSize: '.65rem', color: 'var(--gray-400)', lineHeight: 1.3, maxWidth: 70, marginTop: '.2rem', display: i === currentStep ? 'block' : 'none' }}>{s.desc}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {result.status === 'declined' && (
                <div className="alert alert-danger" style={{ marginBottom: '1.5rem' }}>
                  <div>
                    <strong>Complaint Declined</strong>
                    <p style={{ margin: '.25rem 0 0', fontSize: '.875rem' }}>Your complaint was declined by the reviewing NGO. You may re-submit with additional details or contact your local Labour Office.</p>
                  </div>
                </div>
              )}

              {/* Info Grid */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '.75rem', marginBottom: '1.5rem' }}>
                {[
                  { label: 'Work Location', value: result.workLocation, icon: '📍' },
                  { label: 'Problem Type', value: result.typeOfProblem?.replace(/_/g, ' '), icon: '⚠️' },
                  { label: 'Submitted On', value: new Date(result.createdAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' }), icon: '📅' },
                  { label: 'Last Updated', value: new Date(result.updatedAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' }), icon: '🔄' },
                ].map((item, i) => (
                  <div key={i} style={{ padding: '.75rem', background: 'var(--gray-50)', borderRadius: 8 }}>
                    <div style={{ fontSize: '.72rem', color: 'var(--gray-500)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.04em', display: 'flex', alignItems: 'center', gap: '.3rem', marginBottom: '.3rem' }}>
                      <span>{item.icon}</span>{item.label}
                    </div>
                    <div style={{ fontWeight: 600, color: 'var(--gray-800)', fontSize: '.9rem', textTransform: 'capitalize' }}>{item.value || '—'}</div>
                  </div>
                ))}
              </div>

              {/* Timeline */}
              {result.timeline?.length > 0 && (
                <div>
                  <div style={{ fontWeight: 700, color: 'var(--gray-700)', marginBottom: '1rem', fontSize: '.95rem' }}>📅 Activity History</div>
                  <div className="timeline">
                    {result.timeline.map((tl, i) => (
                      <div key={i} className={`timeline-item ${i < result.timeline.length - 1 ? 'done' : 'active'}`}>
                        <div className="timeline-label">{tl.stage}</div>
                        <div className="timeline-date">{new Date(tl.date).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</div>
                        {tl.note && <div style={{ fontSize: '.82rem', color: 'var(--gray-600)', marginTop: '.25rem' }}>{tl.note}</div>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {!result && !loading && (
          <div className="card" style={{ padding: '2.5rem', textAlign: 'center' }}>
            <div style={{ fontSize: '3.5rem', marginBottom: '1rem' }}>🔍</div>
            <h3 style={{ fontWeight: 700, color: 'var(--gray-700)', marginBottom: '.5rem' }}>Track Your Complaint</h3>
            <p style={{ color: 'var(--gray-500)', marginBottom: '1.5rem' }}>Enter your Complaint ID above to see the current status and progress of your case.</p>
            <div style={{ display: 'flex', gap: '.75rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <button className="btn btn-outline" onClick={() => navigate('/worker/login')}>
                👷 Worker Login
              </button>
              <button className="btn btn-ghost" onClick={() => navigate('/')}>
                🏠 Home
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
