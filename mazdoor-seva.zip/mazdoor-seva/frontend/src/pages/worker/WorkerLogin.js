import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';
import { API } from '../../context/AuthContext';

export default function WorkerLogin() {
  const [step, setStep] = useState(1); // 1: phone, 2: otp
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [name, setName] = useState('');
  const [demoOtp, setDemoOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, language } = useAuth();
  const { t } = useTranslation(language);
  const navigate = useNavigate();

  const handleSendOTP = async (e) => {
    e.preventDefault();
    if (!phone || phone.length < 10) return toast.error('Please enter a valid 10-digit phone number');
    setLoading(true);
    try {
      const res = await API.post('/auth/worker/send-otp', { phone });
      setDemoOtp(res.data.otp_demo);
      setStep(2);
      toast.success('OTP sent! (Demo mode: OTP shown below)');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (e) => {
    e.preventDefault();
    if (!otp || otp.length !== 6) return toast.error('Please enter the 6-digit OTP');
    setLoading(true);
    try {
      const res = await API.post('/auth/worker/verify-otp', { phone, otp, name });
      login(res.data.user, res.data.token);
      toast.success('Welcome to Mazdoor Seva!');
      navigate('/worker/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid OTP');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, var(--primary-light) 0%, #fff 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem 1rem' }}>
      <div style={{ width: '100%', maxWidth: 440 }}>
        {/* Back */}
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/')} style={{ marginBottom: '1.5rem', color: 'var(--gray-600)' }}>
          ← {t('back')}
        </button>

        <div className="card" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <div style={{ background: 'linear-gradient(135deg, var(--primary), var(--primary-dark))', padding: '2rem', borderRadius: '12px 12px 0 0', textAlign: 'center', color: '#fff' }}>
            <div style={{ fontSize: '3rem', marginBottom: '.5rem' }}>👷</div>
            <h2 style={{ fontWeight: 800, fontSize: '1.5rem', marginBottom: '.25rem' }}>
              {language === 'hi' ? 'मज़दूर लॉगिन' : language === 'te' ? 'కార్మికుడు లాగిన్' : 'Worker Login'}
            </h2>
            <p style={{ opacity: .85, fontSize: '.9rem' }}>
              {step === 1 ? t('phoneNumber') : t('enterOTP')}
            </p>
          </div>

          {/* Step indicator */}
          <div style={{ padding: '1.25rem 2rem 0', display: 'flex', gap: 0, alignItems: 'center', justifyContent: 'center' }}>
            {[1, 2].map((s) => (
              <React.Fragment key={s}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontWeight: 700, fontSize: '.85rem', border: '2px solid',
                    borderColor: step >= s ? 'var(--primary)' : 'var(--gray-300)',
                    background: step > s ? 'var(--primary)' : step === s ? 'var(--primary-light)' : '#fff',
                    color: step > s ? '#fff' : step === s ? 'var(--primary)' : 'var(--gray-400)',
                  }}>
                    {step > s ? '✓' : s}
                  </div>
                  <div style={{ fontSize: '.7rem', color: 'var(--gray-500)', marginTop: '.2rem' }}>
                    {s === 1 ? t('phoneNumber') : t('verifyOTP')}
                  </div>
                </div>
                {s < 2 && <div style={{ width: 60, height: 2, background: step > 1 ? 'var(--primary)' : 'var(--gray-200)', margin: '0 .5rem .9rem' }} />}
              </React.Fragment>
            ))}
          </div>

          <div className="card-body" style={{ padding: '1.5rem 2rem 2rem' }}>
            {step === 1 ? (
              <form onSubmit={handleSendOTP}>
                <div className="form-group">
                  <label className="form-label">📱 {t('phoneNumber')}</label>
                  <div style={{ display: 'flex', gap: '.5rem' }}>
                    <div style={{ padding: '.65rem .85rem', background: 'var(--gray-100)', border: '1.5px solid var(--gray-300)', borderRadius: 8, fontWeight: 600, color: 'var(--gray-600)', whiteSpace: 'nowrap' }}>+91</div>
                    <input
                      className="form-control"
                      type="tel"
                      placeholder="Enter 10-digit mobile number"
                      value={phone}
                      onChange={e => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                      required
                      style={{ flex: 1 }}
                    />
                  </div>
                  <p className="form-hint">You'll receive a 6-digit OTP on this number</p>
                </div>
                <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading}>
                  {loading ? <><span className="spinner" /> Sending...</> : `${t('sendOTP')} →`}
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOTP}>
                <div className="form-group">
                  <label className="form-label">{t('yourName')} (optional)</label>
                  <input className="form-control" type="text" placeholder="Enter your name" value={name} onChange={e => setName(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">🔑 {t('enterOTP')}</label>
                  <input
                    className="form-control"
                    type="text"
                    placeholder="Enter 6-digit OTP"
                    value={otp}
                    onChange={e => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    required
                    style={{ fontSize: '1.5rem', letterSpacing: '.3em', textAlign: 'center', fontWeight: 700 }}
                  />
                  {demoOtp && (
                    <div className="alert alert-info" style={{ marginTop: '.75rem' }}>
                      <span>🧪 <strong>Demo Mode:</strong> Your OTP is <strong style={{ fontSize: '1.1rem', letterSpacing: '.1em' }}>{demoOtp}</strong></span>
                    </div>
                  )}
                  <p className="form-hint">OTP sent to +91 {phone} <button type="button" style={{ border: 'none', background: 'none', color: 'var(--primary)', cursor: 'pointer', fontSize: '.8rem', padding: 0 }} onClick={() => setStep(1)}>Change number</button></p>
                </div>
                <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading || otp.length < 6}>
                  {loading ? <><span className="spinner" /> Verifying...</> : `${t('verifyOTP')} ✓`}
                </button>
                <button type="button" className="btn btn-ghost btn-full btn-sm" style={{ marginTop: '.5rem' }} onClick={() => { setStep(1); setOtp(''); }}>
                  ← {t('back')}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
