import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import Navbar from '../../components/common/Navbar';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';

const STEPS = ['Aadhaar Verification', 'Work Details', 'Problem Details', 'Review & Submit'];

const problemTypes = [
  { value: 'unpaid_wages', label: 'Unpaid Wages', icon: '💸' },
  { value: 'partial_payment', label: 'Partial Payment', icon: '🔸' },
  { value: 'illegal_deduction', label: 'Illegal Deduction', icon: '✂️' },
  { value: 'overtime_unpaid', label: 'Overtime Unpaid', icon: '⏰' },
  { value: 'other', label: 'Other', icon: '📌' },
];

const workTypes = ['Mason', 'Carpenter', 'Painter', 'Electrician', 'Plumber', 'Helper/Labour', 'Welder', 'Steel Fixer', 'Supervisor', 'Other'];

export default function RegisterComplaint() {
  const { user, language, API } = useAuth();
  const { t } = useTranslation(language);
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(null);

  const [form, setForm] = useState({
    aadhaar: '', aadhaarVerified: false,
    workLocation: '', contractorName: '', contractorPhone: '', contractorAddress: '',
    typeOfWork: '', dateFrom: '', dateTo: '', salaryAmount: '',
    typeOfProblem: 'unpaid_wages', description: '', isAnonymous: false,
  });

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  // Simulated Aadhaar verification
  const verifyAadhaar = () => {
    if (!form.aadhaar || form.aadhaar.replace(/\s/g, '').length !== 12) {
      return toast.error('Please enter a valid 12-digit Aadhaar number');
    }
    toast.success('Aadhaar verified successfully! ✓');
    set('aadhaarVerified', true);
  };

  const nextStep = () => {
    if (step === 0 && !form.aadhaarVerified) return toast.error('Please verify your Aadhaar first');
    if (step === 1) {
      if (!form.workLocation) return toast.error('Work location is required');
      if (!form.contractorName) return toast.error("Contractor's name is required");
    }
    setStep(s => Math.min(s + 1, STEPS.length - 1));
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const res = await API.post('/complaints', {
        ...form,
        isAnonymous: form.isAnonymous ? 'true' : 'false',
      });
      setSubmitted(res.data);
      toast.success('Complaint submitted successfully!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Submission failed');
    } finally {
      setLoading(false);
    }
  };

  // Success screen
  if (submitted) {
    return (
      <div>
        <Navbar />
        <div style={{ minHeight: 'calc(100vh - 64px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem', background: 'var(--gray-50)' }}>
          <div style={{ maxWidth: 480, width: '100%', textAlign: 'center' }}>
            <div className="card" style={{ boxShadow: 'var(--shadow-lg)', overflow: 'visible' }}>
              <div style={{ background: 'linear-gradient(135deg, var(--success), #15803d)', padding: '2.5rem 2rem', borderRadius: '12px 12px 0 0', color: '#fff' }}>
                <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🎉</div>
                <h2 style={{ fontWeight: 900, fontSize: '1.6rem', marginBottom: '.5rem' }}>{t('complaintSubmitted')}</h2>
                <p style={{ opacity: .9, fontSize: '1rem' }}>Your complaint has been recorded and forwarded</p>
              </div>
              <div className="card-body" style={{ padding: '2rem' }}>
                <div style={{ background: 'var(--primary-light)', border: '2px solid var(--primary)', borderRadius: 12, padding: '1.5rem', marginBottom: '1.5rem' }}>
                  <div style={{ fontSize: '.85rem', color: 'var(--gray-600)', fontWeight: 600, marginBottom: '.5rem' }}>{t('complaintIdGenerated')}</div>
                  <div style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--primary)', letterSpacing: '.1em' }}>{submitted.complaintId}</div>
                  <div style={{ fontSize: '.8rem', color: 'var(--gray-500)', marginTop: '.5rem' }}>Save this ID to track your complaint</div>
                </div>
                <div className="alert alert-info" style={{ textAlign: 'left' }}>
                  📱 {t('smsConfirmation')}
                </div>
                <div style={{ background: 'var(--gray-50)', borderRadius: 8, padding: '1rem', marginBottom: '1.5rem', textAlign: 'left' }}>
                  <div style={{ fontWeight: 700, marginBottom: '.5rem', fontSize: '.9rem' }}>What happens next?</div>
                  {[
                    '🔍 Your complaint will be reviewed by an NGO',
                    '📞 The contractor will be contacted',
                    '⚖️ If needed, Worker Welfare Board will intervene',
                    '✅ You will be notified once resolved',
                  ].map((s, i) => <div key={i} style={{ fontSize: '.85rem', color: 'var(--gray-600)', padding: '.3rem 0' }}>{s}</div>)}
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '.75rem' }}>
                  <button className="btn btn-outline" onClick={() => navigate('/worker/track')}>
                    🔍 Track Complaint
                  </button>
                  <button className="btn btn-primary" onClick={() => navigate('/worker/dashboard')}>
                    🏠 Go to Dashboard
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Navbar />
      <div className="page-header">
        <div className="container">
          <h1>📝 {t('registerComplaint')}</h1>
          <p>{language === 'hi' ? 'अपनी शिकायत दर्ज करें – सभी जानकारी सुरक्षित है' : 'File your complaint – all information is secure'}</p>
        </div>
      </div>

      <div className="container" style={{ padding: '2rem 1.5rem', maxWidth: 700 }}>
        {/* Step progress */}
        <div className="card" style={{ padding: '1.25rem', marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            {STEPS.map((label, i) => (
              <React.Fragment key={i}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1 }}>
                  <div style={{
                    width: 36, height: 36, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontWeight: 700, fontSize: '.85rem', transition: 'all .3s',
                    background: i < step ? 'var(--primary)' : i === step ? 'var(--primary)' : '#fff',
                    border: `2px solid ${i <= step ? 'var(--primary)' : 'var(--gray-300)'}`,
                    color: i <= step ? '#fff' : 'var(--gray-400)',
                  }}>
                    {i < step ? '✓' : i + 1}
                  </div>
                  <div style={{ fontSize: '.65rem', color: i <= step ? 'var(--primary)' : 'var(--gray-400)', marginTop: '.3rem', textAlign: 'center', fontWeight: i === step ? 700 : 400 }}>
                    {label}
                  </div>
                </div>
                {i < STEPS.length - 1 && (
                  <div style={{ flex: 1, height: 2, background: i < step ? 'var(--primary)' : 'var(--gray-200)', maxWidth: 40, margin: '0 .25rem .9rem' }} />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-body" style={{ padding: '2rem' }}>
            {/* STEP 0: Aadhaar */}
            {step === 0 && (
              <div>
                <h3 style={{ fontWeight: 800, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '.5rem' }}>
                  🪪 Aadhaar Verification
                </h3>
                <div className="alert alert-info">
                  Your Aadhaar is used only for identity verification. If you choose to remain anonymous, it will NOT be shared with the contractor.
                </div>
                <div className="form-group">
                  <label className="form-label">{t('aadhaarNumber')} *</label>
                  <div style={{ display: 'flex', gap: '.5rem' }}>
                    <input
                      className="form-control"
                      type="text"
                      placeholder="XXXX XXXX XXXX"
                      value={form.aadhaar}
                      onChange={e => {
                        let v = e.target.value.replace(/\D/g, '').slice(0, 12);
                        v = v.replace(/(.{4})/g, '$1 ').trim();
                        set('aadhaar', v);
                      }}
                      style={{ flex: 1, letterSpacing: '.1em', fontSize: '1.1rem' }}
                      disabled={form.aadhaarVerified}
                    />
                    <button className={`btn ${form.aadhaarVerified ? 'btn-success' : 'btn-primary'}`} onClick={verifyAadhaar} disabled={form.aadhaarVerified} style={{ whiteSpace: 'nowrap' }}>
                      {form.aadhaarVerified ? '✓ Verified' : 'Verify'}
                    </button>
                  </div>
                  {form.aadhaarVerified && <p className="form-hint" style={{ color: 'var(--success)' }}>✓ Aadhaar verified successfully</p>}
                </div>
                <div className="form-group">
                  <label style={{ display: 'flex', alignItems: 'flex-start', gap: '.75rem', cursor: 'pointer', padding: '1rem', background: 'var(--warning-light)', borderRadius: 8, border: '1px solid var(--warning)' }}>
                    <input type="checkbox" checked={form.isAnonymous} onChange={e => set('isAnonymous', e.target.checked)} style={{ marginTop: 3, width: 18, height: 18, accentColor: 'var(--warning)', flexShrink: 0 }} />
                    <div>
                      <div style={{ fontWeight: 700, color: 'var(--gray-800)' }}>🔒 {t('anonymous')}</div>
                      <div style={{ fontSize: '.82rem', color: 'var(--gray-600)', marginTop: '.2rem' }}>Your name and Aadhaar will be hidden from the contractor. Only the NGO and Welfare Board can see your identity.</div>
                    </div>
                  </label>
                </div>
              </div>
            )}

            {/* STEP 1: Work Details */}
            {step === 1 && (
              <div>
                <h3 style={{ fontWeight: 800, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '.5rem' }}>
                  🏗️ Work & Contractor Details
                </h3>
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">{t('workLocation')} *</label>
                    <input className="form-control" placeholder="e.g. Sector 45, Gurugram, Haryana" value={form.workLocation} onChange={e => set('workLocation', e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">{t('typeOfWork')}</label>
                    <select className="form-control" value={form.typeOfWork} onChange={e => set('typeOfWork', e.target.value)}>
                      <option value="">Select type</option>
                      {workTypes.map(w => <option key={w} value={w}>{w}</option>)}
                    </select>
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">{t('contractorName')} *</label>
                  <input className="form-control" placeholder="Full name of contractor/employer" value={form.contractorName} onChange={e => set('contractorName', e.target.value)} />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">{t('contractorPhone')}</label>
                    <input className="form-control" type="tel" placeholder="+91 XXXXX XXXXX" value={form.contractorPhone} onChange={e => set('contractorPhone', e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">{t('salaryAmount')}</label>
                    <div style={{ position: 'relative' }}>
                      <span style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', fontWeight: 700, color: 'var(--gray-500)' }}>₹</span>
                      <input className="form-control" type="number" placeholder="0.00" style={{ paddingLeft: '2rem' }} value={form.salaryAmount} onChange={e => set('salaryAmount', e.target.value)} />
                    </div>
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">{t('contractorAddress')}</label>
                  <textarea className="form-control" style={{ minHeight: 70 }} placeholder="Contractor's office or home address" value={form.contractorAddress} onChange={e => set('contractorAddress', e.target.value)} />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">📅 Work Start Date</label>
                    <input className="form-control" type="date" value={form.dateFrom} onChange={e => set('dateFrom', e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">📅 Work End Date</label>
                    <input className="form-control" type="date" value={form.dateTo} onChange={e => set('dateTo', e.target.value)} />
                  </div>
                </div>
              </div>
            )}

            {/* STEP 2: Problem Details */}
            {step === 2 && (
              <div>
                <h3 style={{ fontWeight: 800, marginBottom: '1.5rem' }}>⚠️ Problem Details</h3>
                <div className="form-group">
                  <label className="form-label">{t('typeOfProblem')} *</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '.75rem' }}>
                    {problemTypes.map(pt => (
                      <label key={pt.value} style={{
                        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '.4rem', padding: '1rem .75rem',
                        border: `2px solid ${form.typeOfProblem === pt.value ? 'var(--primary)' : 'var(--gray-200)'}`,
                        background: form.typeOfProblem === pt.value ? 'var(--primary-light)' : '#fff',
                        borderRadius: 10, cursor: 'pointer', transition: 'all .15s', textAlign: 'center',
                      }}>
                        <input type="radio" name="problem" value={pt.value} checked={form.typeOfProblem === pt.value} onChange={() => set('typeOfProblem', pt.value)} style={{ display: 'none' }} />
                        <span style={{ fontSize: '1.5rem' }}>{pt.icon}</span>
                        <span style={{ fontWeight: 600, fontSize: '.82rem', color: form.typeOfProblem === pt.value ? 'var(--primary)' : 'var(--gray-700)' }}>{pt.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">{t('description')}</label>
                  <textarea className="form-control" rows={5} placeholder="Describe your problem in detail. When did this happen? What was promised vs what was paid? Any witnesses?" value={form.description} onChange={e => set('description', e.target.value)} />
                  <p className="form-hint">More details help the NGO resolve your complaint faster</p>
                </div>
              </div>
            )}

            {/* STEP 3: Review */}
            {step === 3 && (
              <div>
                <h3 style={{ fontWeight: 800, marginBottom: '1.5rem' }}>📋 Review Your Complaint</h3>
                <div style={{ display: 'grid', gap: '.6rem', marginBottom: '1.5rem' }}>
                  {[
                    { label: 'Aadhaar', value: form.aadhaar, icon: '🪪' },
                    { label: 'Anonymous', value: form.isAnonymous ? '🔒 Yes – identity hidden from contractor' : 'No', icon: '👁️' },
                    { label: 'Work Location', value: form.workLocation, icon: '📍' },
                    { label: 'Contractor', value: form.contractorName, icon: '👤' },
                    { label: 'Contractor Phone', value: form.contractorPhone, icon: '📞' },
                    { label: 'Type of Work', value: form.typeOfWork, icon: '🔧' },
                    { label: 'Dates', value: form.dateFrom && form.dateTo ? `${form.dateFrom} to ${form.dateTo}` : form.dateFrom || '—', icon: '📅' },
                    { label: 'Unpaid Amount', value: form.salaryAmount ? `₹${parseFloat(form.salaryAmount).toLocaleString()}` : '—', icon: '💰' },
                    { label: 'Problem Type', value: problemTypes.find(p => p.value === form.typeOfProblem)?.label, icon: '⚠️' },
                    { label: 'Description', value: form.description, icon: '📝' },
                  ].filter(r => r.value).map((row, i) => (
                    <div key={i} style={{ display: 'flex', gap: '.75rem', padding: '.7rem .9rem', background: 'var(--gray-50)', borderRadius: 8 }}>
                      <span style={{ flexShrink: 0 }}>{row.icon}</span>
                      <div>
                        <div style={{ fontSize: '.72rem', color: 'var(--gray-500)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.05em' }}>{row.label}</div>
                        <div style={{ fontWeight: 600, fontSize: '.9rem', color: 'var(--gray-800)' }}>{row.value}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="alert alert-warning">
                  ⚠️ Please review all details carefully. Once submitted, you cannot modify this complaint.
                </div>
              </div>
            )}

            {/* Navigation */}
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '2rem', paddingTop: '1.5rem', borderTop: '1px solid var(--gray-200)' }}>
              <button className="btn btn-ghost" onClick={() => step === 0 ? navigate('/worker/dashboard') : setStep(s => s - 1)}>
                ← {step === 0 ? 'Dashboard' : 'Previous'}
              </button>
              {step < STEPS.length - 1 ? (
                <button className="btn btn-primary btn-lg" onClick={nextStep}>
                  Next Step →
                </button>
              ) : (
                <button className="btn btn-success btn-lg" onClick={handleSubmit} disabled={loading}>
                  {loading ? <><span className="spinner" /> Submitting...</> : '✅ Submit Complaint'}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
