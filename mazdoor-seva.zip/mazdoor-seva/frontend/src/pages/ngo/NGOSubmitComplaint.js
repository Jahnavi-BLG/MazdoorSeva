import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import Navbar from '../../components/common/Navbar';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';

const workTypes = ['Mason', 'Carpenter', 'Painter', 'Electrician', 'Plumber', 'Helper/Labour', 'Welder', 'Steel Fixer', 'Supervisor', 'Other'];
const problemTypes = [
  { value: 'unpaid_wages', label: 'Unpaid Wages' },
  { value: 'partial_payment', label: 'Partial Payment' },
  { value: 'illegal_deduction', label: 'Illegal Deduction' },
  { value: 'overtime_unpaid', label: 'Overtime Unpaid' },
  { value: 'other', label: 'Other' },
];

export default function NGOSubmitComplaint() {
  const { language, API } = useAuth();
  const { t } = useTranslation(language);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(null);
  const [docs, setDocs] = useState([]);
  const [form, setForm] = useState({
    workerName: '', workerPhone: '', workerAadhaar: '',
    workLocation: '', contractorName: '', contractorPhone: '', contractorAddress: '',
    typeOfWork: '', dateFrom: '', dateTo: '', salaryAmount: '',
    typeOfProblem: 'unpaid_wages', description: '',
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.workLocation || !form.contractorName || !form.workerName)
      return toast.error('Worker name, work location, and contractor name are required');
    setLoading(true);
    const fd = new FormData();
    Object.entries(form).forEach(([k, v]) => fd.append(k, v));
    docs.forEach(d => fd.append('proofDocuments', d));
    try {
      const res = await API.post('/complaints/ngo/submit', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      setSubmitted(res.data);
      toast.success('Complaint submitted successfully!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Submission failed');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div><Navbar />
        <div style={{ minHeight: 'calc(100vh - 64px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
          <div className="card" style={{ maxWidth: 460, width: '100%', boxShadow: 'var(--shadow-lg)', textAlign: 'center' }}>
            <div style={{ background: 'linear-gradient(135deg, var(--success), #15803d)', padding: '2.5rem', borderRadius: '12px 12px 0 0', color: '#fff' }}>
              <div style={{ fontSize: '3.5rem', marginBottom: '1rem' }}>🎉</div>
              <h2 style={{ fontWeight: 900, fontSize: '1.5rem', marginBottom: '.5rem' }}>Complaint Submitted!</h2>
              <p style={{ opacity: .9 }}>Successfully filed on behalf of the worker</p>
            </div>
            <div className="card-body" style={{ padding: '2rem' }}>
              <div style={{ background: 'var(--primary-light)', border: '2px solid var(--primary)', borderRadius: 12, padding: '1.25rem', marginBottom: '1.5rem' }}>
                <div style={{ fontSize: '.85rem', color: 'var(--gray-600)', fontWeight: 600, marginBottom: '.4rem' }}>Complaint ID</div>
                <div style={{ fontSize: '1.8rem', fontWeight: 900, color: 'var(--primary)', letterSpacing: '.1em' }}>{submitted.complaintId}</div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '.75rem' }}>
                <button className="btn btn-outline" onClick={() => navigate('/ngo/dashboard')}>← Dashboard</button>
                <button className="btn btn-secondary" onClick={() => { setSubmitted(null); setForm({ workerName:'', workerPhone:'', workerAadhaar:'', workLocation:'', contractorName:'', contractorPhone:'', contractorAddress:'', typeOfWork:'', dateFrom:'', dateTo:'', salaryAmount:'', typeOfProblem:'unpaid_wages', description:'' }); }}>
                  ➕ New Complaint
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Navbar />
      <div className="page-header" style={{ background: 'linear-gradient(135deg, var(--secondary), var(--secondary-dark))' }}>
        <div className="container">
          <h1>📝 {t('submitOnBehalf')}</h1>
          <p>Submit a complaint on behalf of a worker who cannot access the platform</p>
        </div>
      </div>

      <div className="container" style={{ padding: '2rem 1.5rem', maxWidth: 760 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/ngo/dashboard')} style={{ marginBottom: '1.25rem' }}>
          ← Back to Dashboard
        </button>

        <form onSubmit={handleSubmit}>
          {/* Worker Details */}
          <div className="card" style={{ marginBottom: '1.25rem' }}>
            <div className="card-header"><span className="card-title">👷 Worker Details</span></div>
            <div className="card-body">
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">{t('workerName')} *</label>
                  <input className="form-control" placeholder="Full name" value={form.workerName} onChange={e => set('workerName', e.target.value)} required />
                </div>
                <div className="form-group">
                  <label className="form-label">{t('workerPhone')}</label>
                  <input className="form-control" type="tel" placeholder="+91 XXXXX XXXXX" value={form.workerPhone} onChange={e => set('workerPhone', e.target.value)} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">{t('workerAadhaar')}</label>
                <input className="form-control" placeholder="XXXX XXXX XXXX" value={form.workerAadhaar}
                  onChange={e => { let v = e.target.value.replace(/\D/g,'').slice(0,12); v = v.replace(/(.{4})/g,'$1 ').trim(); set('workerAadhaar', v); }} />
              </div>
            </div>
          </div>

          {/* Work & Contractor Details */}
          <div className="card" style={{ marginBottom: '1.25rem' }}>
            <div className="card-header"><span className="card-title">🏗️ Work & Contractor Details</span></div>
            <div className="card-body">
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">{t('workLocation')} *</label>
                  <input className="form-control" placeholder="Work site address" value={form.workLocation} onChange={e => set('workLocation', e.target.value)} required />
                </div>
                <div className="form-group">
                  <label className="form-label">{t('typeOfWork')}</label>
                  <select className="form-control" value={form.typeOfWork} onChange={e => set('typeOfWork', e.target.value)}>
                    <option value="">Select type</option>
                    {workTypes.map(w => <option key={w} value={w}>{w}</option>)}
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">{t('contractorName')} *</label>
                <input className="form-control" placeholder="Full name of contractor" value={form.contractorName} onChange={e => set('contractorName', e.target.value)} required />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">{t('contractorPhone')}</label>
                  <input className="form-control" type="tel" placeholder="+91 XXXXX XXXXX" value={form.contractorPhone} onChange={e => set('contractorPhone', e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">{t('salaryAmount')}</label>
                  <div style={{ position: 'relative' }}>
                    <span style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', fontWeight: 700, color: 'var(--gray-500)' }}>₹</span>
                    <input className="form-control" type="number" placeholder="0" style={{ paddingLeft: '2rem' }} value={form.salaryAmount} onChange={e => set('salaryAmount', e.target.value)} />
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Work Start Date</label>
                  <input className="form-control" type="date" value={form.dateFrom} onChange={e => set('dateFrom', e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Work End Date</label>
                  <input className="form-control" type="date" value={form.dateTo} onChange={e => set('dateTo', e.target.value)} />
                </div>
              </div>
            </div>
          </div>

          {/* Problem Details */}
          <div className="card" style={{ marginBottom: '1.25rem' }}>
            <div className="card-header"><span className="card-title">⚠️ Problem Details</span></div>
            <div className="card-body">
              <div className="form-group">
                <label className="form-label">{t('typeOfProblem')}</label>
                <select className="form-control" value={form.typeOfProblem} onChange={e => set('typeOfProblem', e.target.value)}>
                  {problemTypes.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">{t('description')}</label>
                <textarea className="form-control" rows={5} placeholder="Detailed description of the problem..." value={form.description} onChange={e => set('description', e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">📎 {t('proofDocuments')}</label>
                <input className="form-control" type="file" multiple accept=".pdf,.jpg,.jpeg,.png" onChange={e => setDocs(Array.from(e.target.files))} style={{ padding: '.5rem' }} />
                <p className="form-hint">Upload salary slips, work photos, or other supporting documents (max 5 files, 10MB each)</p>
                {docs.length > 0 && (
                  <div style={{ marginTop: '.5rem' }}>
                    {docs.map((d, i) => (
                      <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: '.3rem', background: 'var(--primary-light)', color: 'var(--primary)', padding: '.2rem .6rem', borderRadius: 6, fontSize: '.8rem', margin: '.2rem', fontWeight: 600 }}>
                        📄 {d.name}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.75rem' }}>
            <button type="button" className="btn btn-ghost" onClick={() => navigate('/ngo/dashboard')}>Cancel</button>
            <button type="submit" className="btn btn-secondary btn-lg" disabled={loading}>
              {loading ? <><span className="spinner" /> Submitting...</> : '✅ Submit Complaint'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
