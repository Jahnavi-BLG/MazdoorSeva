import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import Navbar from '../../components/common/Navbar';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';

const statusColors = {
  submitted: '#6b7280', under_review: '#d97706', investigation: '#0891b2',
  worker_welfare: '#7c3aed', resolved: '#16a34a', declined: '#dc2626',
};

export default function NGOComplaintDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { language, API } = useAuth();
  const { t } = useTranslation(language);
  const [complaint, setComplaint] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState('');
  const [notes, setNotes] = useState('');
  const [priority, setPriority] = useState('medium');
  const [showDeclineConfirm, setShowDeclineConfirm] = useState(false);

  useEffect(() => {
    API.get(`/complaints/ngo/${id}`)
      .then(res => {
        setComplaint(res.data.complaint);
        setNotes(res.data.complaint.ngoWorkflow?.ngoNotes || '');
        setPriority(res.data.complaint.priority || 'medium');
      })
      .catch(() => { toast.error('Complaint not found'); navigate('/ngo/dashboard'); })
      .finally(() => setLoading(false));
  }, [id]);

  const doAction = async (endpoint, body = {}, successMsg) => {
    setActionLoading(endpoint);
    try {
      const res = await API.patch(`/complaints/ngo/${id}/${endpoint}`, body);
      setComplaint(res.data.complaint);
      toast.success(successMsg);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Action failed');
    } finally {
      setActionLoading('');
    }
  };

  const doWorkflow = async (step, value, msg) => {
    setActionLoading(step);
    try {
      const res = await API.patch(`/complaints/ngo/${id}/workflow`, { step, value, notes });
      setComplaint(res.data.complaint);
      toast.success(msg);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally {
      setActionLoading('');
    }
  };

  const formatDate = (d) => d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' }) : '—';

  if (loading) return (
    <div><Navbar />
      <div style={{ display: 'flex', justifyContent: 'center', padding: '5rem' }}>
        <div className="spinner spinner-dark" style={{ width: 48, height: 48 }} />
      </div>
    </div>
  );

  if (!complaint) return null;

  const wf = complaint.ngoWorkflow || {};
  const sc = statusColors[complaint.status] || '#6b7280';
  const isAccepted = ['under_review', 'investigation', 'worker_welfare', 'resolved'].includes(complaint.status);
  const isDeclined = complaint.status === 'declined';

  // Workflow step definitions
  const workflowSteps = [
    {
      num: 1, key: 'inform_contractor',
      title: t('informContractor'),
      desc: 'Notify the contractor about the complaint and request a response.',
      done: wf.contractorInformed,
      active: isAccepted && !wf.contractorInformed,
      action: () => doWorkflow('inform_contractor', null, 'Contractor has been informed!'),
    },
    {
      num: 2, key: 'contractor_response',
      title: t('contractorResponse'),
      desc: wf.contractorInformed
        ? (wf.contractorResponse === 'responded' ? '✅ Contractor responded'
          : wf.contractorResponse === 'no_response' ? '❌ No response – escalation triggered'
          : `Waiting for contractor response${wf.contractorInformedDate ? ` (informed on ${formatDate(wf.contractorInformedDate)})` : ''}`)
        : 'Waiting for contractor to be informed first.',
      done: wf.contractorResponse !== 'pending' && wf.contractorResponse,
      active: isAccepted && wf.contractorInformed && (!wf.contractorResponse || wf.contractorResponse === 'pending'),
      showResponseButtons: isAccepted && wf.contractorInformed && (!wf.contractorResponse || wf.contractorResponse === 'pending'),
    },
    {
      num: 3, key: 'escalate_welfare',
      title: t('escalateToWelfare'),
      desc: 'Escalate to the Worker Welfare Board for formal investigation.',
      done: wf.escalatedToWelfare,
      active: isAccepted && wf.contractorResponse === 'no_response' && !wf.escalatedToWelfare,
      action: () => doWorkflow('escalate_welfare', null, 'Escalated to Worker Welfare Board!'),
    },
    {
      num: 4, key: 'resolve',
      title: 'Mark as Resolved',
      desc: 'Mark this complaint as resolved after successful intervention.',
      done: complaint.status === 'resolved',
      active: isAccepted && (wf.contractorResponse === 'responded' || wf.escalatedToWelfare) && complaint.status !== 'resolved',
      action: () => doWorkflow('resolve', null, 'Complaint marked as Resolved!'),
    },
  ];

  return (
    <div>
      <Navbar />

      {/* Header */}
      <div style={{ background: '#fff', borderBottom: '1px solid var(--gray-200)', padding: '1.25rem 1.5rem' }}>
        <div className="container" style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
          <button className="btn btn-ghost btn-sm" onClick={() => navigate('/ngo/dashboard')}>← Dashboard</button>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', flexWrap: 'wrap' }}>
              <span style={{ fontWeight: 900, fontSize: '1.1rem' }}>🆔 {complaint.complaintId}</span>
              <span style={{ background: `${sc}22`, color: sc, padding: '.3rem .75rem', borderRadius: 999, fontWeight: 700, fontSize: '.82rem', textTransform: 'uppercase' }}>
                {complaint.status.replace(/_/g, ' ')}
              </span>
              {complaint.contractorFlagCount > 0 && (
                <span className="flag-warning">🚩 Flagged – {complaint.contractorFlagCount} prior complaints</span>
              )}
            </div>
          </div>
          <div style={{ display: 'flex', gap: '.5rem' }}>
            <select className="form-control" style={{ width: 'auto', padding: '.4rem .75rem' }} value={priority}
              onChange={async e => { setPriority(e.target.value); await doWorkflow('priority', e.target.value, 'Priority updated!'); }}>
              <option value="high">🔴 High Priority</option>
              <option value="medium">🟡 Medium Priority</option>
              <option value="low">🟢 Low Priority</option>
            </select>
          </div>
        </div>
      </div>

      <div className="container" style={{ padding: '1.5rem', maxWidth: 1100 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>

          {/* LEFT: Details */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            {/* Worker Details */}
            <div className="card">
              <div className="card-header">
                <span className="card-title">👷 {t('workerDetails')}</span>
                {complaint.isAnonymous && <span style={{ background: '#f3f4f6', padding: '.2rem .6rem', borderRadius: 6, fontSize: '.75rem', fontWeight: 600, color: '#6b7280' }}>🔒 Anonymous</span>}
              </div>
              <div className="card-body">
                {complaint.isAnonymous ? (
                  <div className="alert alert-warning">
                    🔒 Worker chose to remain anonymous to the contractor. Details are hidden.
                  </div>
                ) : (
                  <div style={{ display: 'grid', gap: '.6rem' }}>
                    {[
                      { label: 'Name', value: complaint.workerName, icon: '👤' },
                      { label: 'Phone', value: complaint.workerPhone, icon: '📱' },
                      { label: 'Aadhaar', value: complaint.workerAadhaar ? `****${complaint.workerAadhaar.slice(-4)}` : '—', icon: '🪪' },
                    ].map((r, i) => (
                      <div key={i} style={{ display: 'flex', gap: '.6rem', alignItems: 'center', padding: '.5rem .75rem', background: 'var(--gray-50)', borderRadius: 6 }}>
                        <span>{r.icon}</span>
                        <div>
                          <div style={{ fontSize: '.72rem', color: 'var(--gray-500)', fontWeight: 600, textTransform: 'uppercase' }}>{r.label}</div>
                          <div style={{ fontWeight: 600, color: 'var(--gray-800)' }}>{r.value || '—'}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Contractor Details */}
            <div className="card">
              <div className="card-header">
                <span className="card-title">🏗️ {t('contractorDetails')}</span>
                {complaint.contractorFlagCount > 0 && (
                  <span className="flag-warning">🚩 {complaint.contractorFlagCount} complaints</span>
                )}
              </div>
              <div className="card-body">
                <div style={{ display: 'grid', gap: '.6rem' }}>
                  {[
                    { label: 'Name', value: complaint.contractorName, icon: '👤' },
                    { label: 'Phone', value: complaint.contractorPhone, icon: '📞' },
                    { label: 'Address', value: complaint.contractorAddress, icon: '📍' },
                  ].map((r, i) => (
                    <div key={i} style={{ display: 'flex', gap: '.6rem', alignItems: 'flex-start', padding: '.5rem .75rem', background: 'var(--gray-50)', borderRadius: 6 }}>
                      <span style={{ flexShrink: 0 }}>{r.icon}</span>
                      <div>
                        <div style={{ fontSize: '.72rem', color: 'var(--gray-500)', fontWeight: 600, textTransform: 'uppercase' }}>{r.label}</div>
                        <div style={{ fontWeight: 600, color: 'var(--gray-800)' }}>{r.value || '—'}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Complaint Details */}
            <div className="card">
              <div className="card-header"><span className="card-title">📋 {t('complaintDetails')}</span></div>
              <div className="card-body">
                <div style={{ display: 'grid', gap: '.6rem' }}>
                  {[
                    { label: 'Work Location', value: complaint.workLocation, icon: '📍' },
                    { label: 'Type of Work', value: complaint.typeOfWork, icon: '🔧' },
                    { label: 'Problem Type', value: complaint.typeOfProblem?.replace(/_/g, ' '), icon: '⚠️' },
                    { label: 'Unpaid Amount', value: complaint.salaryAmount ? `₹${complaint.salaryAmount.toLocaleString()}` : null, icon: '💰' },
                    { label: 'Work Period', value: complaint.datesWorked?.from ? `${formatDate(complaint.datesWorked.from)} – ${formatDate(complaint.datesWorked.to)}` : null, icon: '📅' },
                    { label: 'Submitted On', value: formatDate(complaint.createdAt), icon: '🗓️' },
                  ].filter(r => r.value).map((r, i) => (
                    <div key={i} style={{ display: 'flex', gap: '.6rem', alignItems: 'flex-start', padding: '.5rem .75rem', background: 'var(--gray-50)', borderRadius: 6 }}>
                      <span style={{ flexShrink: 0 }}>{r.icon}</span>
                      <div>
                        <div style={{ fontSize: '.72rem', color: 'var(--gray-500)', fontWeight: 600, textTransform: 'uppercase' }}>{r.label}</div>
                        <div style={{ fontWeight: 600, color: 'var(--gray-800)', textTransform: 'capitalize' }}>{r.value}</div>
                      </div>
                    </div>
                  ))}
                  {complaint.description && (
                    <div style={{ padding: '.75rem', background: 'var(--gray-50)', borderRadius: 6, borderLeft: '3px solid var(--primary)' }}>
                      <div style={{ fontSize: '.72rem', color: 'var(--gray-500)', fontWeight: 600, textTransform: 'uppercase', marginBottom: '.3rem' }}>📝 Description</div>
                      <div style={{ color: 'var(--gray-700)', lineHeight: 1.6, fontSize: '.9rem' }}>{complaint.description}</div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT: Actions + Workflow */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>

            {/* Accept / Decline (only if just submitted) */}
            {complaint.status === 'submitted' && (
              <div className="card" style={{ border: '2px solid var(--primary)' }}>
                <div className="card-header" style={{ background: 'var(--primary-light)' }}>
                  <span className="card-title" style={{ color: 'var(--primary)' }}>🎯 Action Required</span>
                </div>
                <div className="card-body">
                  <p style={{ color: 'var(--gray-600)', marginBottom: '1.25rem', fontSize: '.9rem' }}>
                    Review the complaint details and decide whether to accept or decline this case.
                  </p>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '.75rem' }}>
                    <button className="btn btn-success btn-lg" onClick={() => doAction('accept', { priority }, 'Complaint accepted!')} disabled={actionLoading === 'accept'}>
                      {actionLoading === 'accept' ? <span className="spinner" /> : '✅'} {t('accept')}
                    </button>
                    <button className="btn btn-danger" onClick={() => setShowDeclineConfirm(true)}>
                      ❌ {t('decline')}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Decline Confirm Modal */}
            {showDeclineConfirm && (
              <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 999, padding: '1rem' }}>
                <div className="card" style={{ maxWidth: 400, width: '100%', boxShadow: 'var(--shadow-lg)' }}>
                  <div className="card-body" style={{ textAlign: 'center', padding: '2rem' }}>
                    <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>⚠️</div>
                    <h3 style={{ fontWeight: 800, marginBottom: '.75rem' }}>Decline this Complaint?</h3>
                    <p style={{ color: 'var(--gray-600)', marginBottom: '1.5rem', fontSize: '.9rem' }}>The complaint will be disabled and returned to the queue. This action cannot be undone easily.</p>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '.75rem' }}>
                      <button className="btn btn-ghost" onClick={() => setShowDeclineConfirm(false)}>Cancel</button>
                      <button className="btn btn-danger" onClick={() => { setShowDeclineConfirm(false); doAction('decline', {}, 'Complaint declined'); navigate('/ngo/dashboard'); }}>
                        Confirm Decline
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Workflow Checklist */}
            {(isAccepted || isDeclined) && (
              <div className="card">
                <div className="card-header">
                  <span className="card-title">📋 {t('ngoWorkflow')}</span>
                </div>
                <div className="card-body">
                  {isDeclined ? (
                    <div className="alert alert-danger">This complaint has been declined and is no longer active.</div>
                  ) : (
                    workflowSteps.map(ws => (
                      <div key={ws.key} className={`checklist-step ${ws.done ? 'completed' : ws.active ? 'active' : ''}`}>
                        <div className="checklist-num">{ws.done ? '✓' : ws.num}</div>
                        <div className="checklist-content">
                          <div className="checklist-title">{ws.title}</div>
                          <div className="checklist-desc">{ws.desc}</div>
                          {ws.showResponseButtons && (
                            <div style={{ display: 'flex', gap: '.6rem', marginTop: '.75rem', flexWrap: 'wrap' }}>
                              <button className="btn btn-success btn-sm" onClick={() => doWorkflow('contractor_response', 'responded', 'Contractor response recorded!')} disabled={!!actionLoading}>
                                ✅ {t('responded')}
                              </button>
                              <button className="btn btn-danger btn-sm" onClick={() => doWorkflow('contractor_response', 'no_response', 'No response recorded – consider escalation')} disabled={!!actionLoading}>
                                ❌ {t('noResponse')}
                              </button>
                            </div>
                          )}
                          {ws.action && ws.active && !ws.done && (
                            <button className="btn btn-primary btn-sm" style={{ marginTop: '.75rem' }} onClick={ws.action} disabled={!!actionLoading}>
                              {actionLoading === ws.key ? <><span className="spinner" /> Processing...</> : `→ ${ws.title}`}
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Internal Notes */}
            {isAccepted && (
              <div className="card">
                <div className="card-header"><span className="card-title">📝 {t('notes')}</span></div>
                <div className="card-body">
                  <textarea className="form-control" rows={4} placeholder="Add internal notes about this case..." value={notes} onChange={e => setNotes(e.target.value)} />
                  <button className="btn btn-outline btn-sm" style={{ marginTop: '.75rem' }}
                    onClick={() => doWorkflow('notes_only', null, 'Notes saved!')}>
                    💾 {t('saveNotes')}
                  </button>
                </div>
              </div>
            )}

            {/* Timeline */}
            {complaint.timeline?.length > 0 && (
              <div className="card">
                <div className="card-header"><span className="card-title">📅 Timeline</span></div>
                <div className="card-body">
                  <div className="timeline">
                    {complaint.timeline.map((tl, i) => (
                      <div key={i} className={`timeline-item ${i < complaint.timeline.length - 1 ? 'done' : 'active'}`}>
                        <div className="timeline-label">{tl.stage}</div>
                        <div className="timeline-date">{new Date(tl.date).toLocaleString('en-IN')}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
