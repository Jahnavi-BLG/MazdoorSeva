import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';
import { API } from '../../context/AuthContext';

export default function NGORegister() {
  const [form, setForm] = useState({
    ngoName: '', ngoEmail: '', ngoPhone: '', ngoAddress: '', ngoRegNumber: '',
    password: '', confirmPassword: '',
  });
  const [docFile, setDocFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const { login, language } = useAuth();
  const { t } = useTranslation(language);
  const navigate = useNavigate();
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) return toast.error('Passwords do not match');
    if (form.password.length < 6) return toast.error('Password must be at least 6 characters');

    const fd = new FormData();
    Object.entries(form).forEach(([k, v]) => { if (k !== 'confirmPassword') fd.append(k, v); });
    if (docFile) fd.append('ngoDocument', docFile);

    setLoading(true);
    try {
      const res = await API.post('/auth/ngo/register', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      login(res.data.user, res.data.token);
      toast.success(`${res.data.user.ngoName} registered successfully!`);
      navigate('/ngo/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #fff7ed 0%, #fff 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem 1rem' }}>
      <div style={{ width: '100%', maxWidth: 520 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/')} style={{ marginBottom: '1.5rem' }}>
          ← Back to Home
        </button>

        <div className="card" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <div style={{ background: 'linear-gradient(135deg, var(--secondary), var(--secondary-dark))', padding: '2rem', borderRadius: '12px 12px 0 0', textAlign: 'center', color: '#fff' }}>
            <div style={{ fontSize: '3rem', marginBottom: '.5rem' }}>🏛️</div>
            <h2 style={{ fontWeight: 800, fontSize: '1.5rem', marginBottom: '.25rem' }}>{t('registerAsNGO')}</h2>
            <p style={{ opacity: .85, fontSize: '.9rem' }}>Register your organization to assist workers</p>
          </div>
          <div className="card-body" style={{ padding: '2rem' }}>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">🏛️ {t('ngoName')} *</label>
                <input className="form-control" placeholder="Full organization name" value={form.ngoName} onChange={e => set('ngoName', e.target.value)} required />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">📧 {t('ngoEmail')} *</label>
                  <input className="form-control" type="email" placeholder="contact@ngo.org" value={form.ngoEmail} onChange={e => set('ngoEmail', e.target.value)} required />
                </div>
                <div className="form-group">
                  <label className="form-label">📱 {t('ngoPhone')}</label>
                  <input className="form-control" type="tel" placeholder="+91 XXXXX XXXXX" value={form.ngoPhone} onChange={e => set('ngoPhone', e.target.value)} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">🏢 {t('ngoAddress')}</label>
                <textarea className="form-control" style={{ minHeight: 70 }} placeholder="Organization address" value={form.ngoAddress} onChange={e => set('ngoAddress', e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">📋 {t('ngoRegNumber')}</label>
                <input className="form-control" placeholder="e.g. NGO-REG-XXXX-2024" value={form.ngoRegNumber} onChange={e => set('ngoRegNumber', e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">📄 {t('ngoDocument')}</label>
                <input className="form-control" type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={e => setDocFile(e.target.files[0])} style={{ padding: '.5rem' }} />
                <p className="form-hint">Upload registration certificate or government authorization (max 5MB)</p>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">🔒 {t('password')} *</label>
                  <input className="form-control" type="password" placeholder="Min 6 characters" value={form.password} onChange={e => set('password', e.target.value)} required minLength={6} />
                </div>
                <div className="form-group">
                  <label className="form-label">🔒 {t('confirmPassword')} *</label>
                  <input className="form-control" type="password" placeholder="Re-enter password" value={form.confirmPassword} onChange={e => set('confirmPassword', e.target.value)} required />
                </div>
              </div>
              <button type="submit" className="btn btn-secondary btn-full btn-lg" disabled={loading} style={{ marginTop: '.5rem' }}>
                {loading ? <><span className="spinner" /> Registering...</> : `✅ ${t('register')}`}
              </button>
            </form>
            <div style={{ textAlign: 'center', marginTop: '1.5rem', paddingTop: '1.5rem', borderTop: '1px solid var(--gray-200)' }}>
              <p style={{ color: 'var(--gray-600)', fontSize: '.9rem' }}>
                {t('alreadyHaveAccount')}{' '}
                <button className="btn btn-ghost btn-sm" style={{ color: 'var(--secondary)', fontWeight: 700 }} onClick={() => navigate('/ngo/login')}>
                  {t('login')} →
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
