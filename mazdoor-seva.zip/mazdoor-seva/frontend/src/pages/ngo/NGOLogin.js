import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';
import { API } from '../../context/AuthContext';

export default function NGOLogin() {
  const [form, setForm] = useState({ ngoEmail: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { login, language } = useAuth();
  const { t } = useTranslation(language);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await API.post('/auth/ngo/login', form);
      login(res.data.user, res.data.token);
      toast.success(`Welcome back, ${res.data.user.ngoName}!`);
      navigate('/ngo/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #fff7ed 0%, #fff 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem 1rem' }}>
      <div style={{ width: '100%', maxWidth: 440 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/')} style={{ marginBottom: '1.5rem' }}>
          ← Back to Home
        </button>

        <div className="card" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <div style={{ background: 'linear-gradient(135deg, var(--secondary), var(--secondary-dark))', padding: '2rem', borderRadius: '12px 12px 0 0', textAlign: 'center', color: '#fff' }}>
            <div style={{ fontSize: '3rem', marginBottom: '.5rem' }}>🏛️</div>
            <h2 style={{ fontWeight: 800, fontSize: '1.5rem', marginBottom: '.25rem' }}>{t('loginAsNGO')}</h2>
            <p style={{ opacity: .85, fontSize: '.9rem' }}>Access the NGO complaint management portal</p>
          </div>
          <div className="card-body" style={{ padding: '2rem' }}>
            <form onSubmit={handleLogin}>
              <div className="form-group">
                <label className="form-label">📧 {t('ngoEmail')}</label>
                <input className="form-control" type="email" placeholder="your@ngo.org" value={form.ngoEmail} onChange={e => setForm(f => ({ ...f, ngoEmail: e.target.value }))} required />
              </div>
              <div className="form-group">
                <label className="form-label">🔒 {t('password')}</label>
                <input className="form-control" type="password" placeholder="••••••••" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} required />
              </div>
              <button type="submit" className="btn btn-secondary btn-full btn-lg" disabled={loading} style={{ marginTop: '.5rem' }}>
                {loading ? <><span className="spinner" /> Signing in...</> : `${t('login')} →`}
              </button>
            </form>
            <div style={{ textAlign: 'center', marginTop: '1.5rem', paddingTop: '1.5rem', borderTop: '1px solid var(--gray-200)' }}>
              <p style={{ color: 'var(--gray-600)', fontSize: '.9rem' }}>
                {t('dontHaveAccount')}{' '}
                <button className="btn btn-ghost btn-sm" style={{ color: 'var(--secondary)', fontWeight: 700 }} onClick={() => navigate('/ngo/register')}>
                  {t('registerAsNGO')} →
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
