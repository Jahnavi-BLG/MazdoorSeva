import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import Navbar from '../../components/common/Navbar';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';

const statusConfig = {
  submitted: { label: 'Submitted', badge: 'badge-submitted', icon: '📋' },
  under_review: { label: 'Under Review', badge: 'badge-under_review', icon: '🔍' },
  investigation: { label: 'Investigation', badge: 'badge-investigation', icon: '🕵️' },
  worker_welfare: { label: 'Worker Welfare', badge: 'badge-worker_welfare', icon: '⚖️' },
  resolved: { label: 'Resolved', badge: 'badge-resolved', icon: '✅' },
  declined: { label: 'Declined', badge: 'badge-declined', icon: '❌' },
};

export default function NGODashboard() {
  const { user, language, API } = useAuth();
  const { t } = useTranslation(language);
  const navigate = useNavigate();
  const [complaints, setComplaints] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ status: '', priority: '' });

  const fetchComplaints = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filter.status) params.set('status', filter.status);
      if (filter.priority) params.set('priority', filter.priority);
      const [cRes, sRes] = await Promise.all([
        API.get(`/complaints/ngo/all?${params}`),
        API.get('/complaints/ngo/stats/summary'),
      ]);
      setComplaints(cRes.data.complaints);
      setStats(sRes.data.stats);
    } catch (err) {
      toast.error('Failed to load complaints');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchComplaints(); }, [filter]);

  const formatDate = (d) => d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

  return (
    <div>
      <Navbar />
      <div className="page-header" style={{ background: 'linear-gradient(135deg, var(--secondary) 0%, var(--secondary-dark) 100%)' }}>
        <div className="container">
          <h1>🏛️ {user?.ngoName || 'NGO'} Dashboard</h1>
          <p>Manage and resolve worker complaints</p>
        </div>
      </div>

      <div className="container" style={{ padding: '2rem 1.5rem' }}>
        {/* Stats */}
        {stats && (
          <div className="stats-grid" style={{ marginBottom: '2rem' }}>
            {[
              { label: t('totalComplaints'), value: stats.total, icon: '📊', color: 'var(--primary)' },
              { label: 'Pending Review', value: stats.submitted, icon: '📋', color: 'var(--gray-500)' },
              { label: 'Under Review', value: stats.under_review, icon: '🔍', color: 'var(--warning)' },
              { label: 'Investigation', value: stats.investigation, icon: '🕵️', color: 'var(--info)' },
              { label: 'Worker Welfare', value: stats.worker_welfare, icon: '⚖️', color: '#7c3aed' },
              { label: t('resolvedCases'), value: stats.resolved, icon: '✅', color: 'var(--success)' },
            ].map((s, i) => (
              <div key={i} className="stat-card" style={{ borderTop: `4px solid ${s.color}` }}>
                <div style={{ fontSize: '1.5rem', marginBottom: '.25rem' }}>{s.icon}</div>
                <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
                <div className="stat-label">{s.label}</div>
              </div>
            ))}
          </div>
        )}

        {/* Actions Row */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '.75rem' }}>
          <h2 style={{ fontWeight: 800, fontSize: '1.2rem' }}>📋 Complaints Queue</h2>
          <div style={{ display: 'flex', gap: '.75rem', flexWrap: 'wrap' }}>
            <button className="btn btn-secondary btn-sm" onClick={() => navigate('/ngo/submit-complaint')}>
              ➕ Submit on Behalf of Worker
            </button>
            <button className="btn btn-outline btn-sm" onClick={fetchComplaints}>
              🔄 Refresh
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="card" style={{ padding: '1rem 1.25rem', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
            <span style={{ fontWeight: 600, color: 'var(--gray-600)', fontSize: '.9rem' }}>🔽 Filter:</span>
            <select className="form-control" style={{ width: 'auto', padding: '.4rem .75rem' }} value={filter.status} onChange={e => setFilter(f => ({ ...f, status: e.target.value }))}>
              <option value="">All Statuses</option>
              <option value="submitted">Submitted</option>
              <option value="under_review">Under Review</option>
              <option value="investigation">Investigation</option>
              <option value="worker_welfare">Worker Welfare</option>
              <option value="resolved">Resolved</option>
            </select>
            <select className="form-control" style={{ width: 'auto', padding: '.4rem .75rem' }} value={filter.priority} onChange={e => setFilter(f => ({ ...f, priority: e.target.value }))}>
              <option value="">All Priorities</option>
              <option value="high">High Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="low">Low Priority</option>
            </select>
            {(filter.status || filter.priority) && (
              <button className="btn btn-ghost btn-sm" onClick={() => setFilter({ status: '', priority: '' })}>✕ Clear Filters</button>
            )}
          </div>
        </div>

        {/* Complaints Table */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--gray-400)' }}>
            <div className="spinner spinner-dark" style={{ width: 36, height: 36, margin: '0 auto 1rem' }} />
            <p>{t('loadingComplaints')}</p>
          </div>
        ) : complaints.length === 0 ? (
          <div className="card" style={{ padding: '4rem', textAlign: 'center' }}>
            <div style={{ fontSize: '3.5rem', marginBottom: '1rem' }}>📭</div>
            <p style={{ color: 'var(--gray-500)', fontSize: '1.1rem' }}>{t('noComplaintsFound')}</p>
          </div>
        ) : (
          <div>
            {complaints.map(c => {
              const sc = statusConfig[c.status] || statusConfig.submitted;
              return (
                <div key={c._id} className="complaint-card" onClick={() => navigate(`/ngo/complaint/${c._id}`)}>
                  <div className="complaint-card-header">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem' }}>
                      <span className="complaint-id">🆔 {c.complaintId}</span>
                      {c.contractorFlagCount > 0 && (
                        <span className="flag-warning">🚩 {c.contractorFlagCount} previous</span>
                      )}
                    </div>
                    <div style={{ display: 'flex', gap: '.5rem', alignItems: 'center' }}>
                      <span className={`badge badge-${c.priority}`}>{c.priority}</span>
                      <span className={`badge ${sc.badge}`}>{sc.icon} {sc.label}</span>
                    </div>
                  </div>
                  <div style={{ fontWeight: 700, fontSize: '1rem', color: 'var(--gray-900)', marginBottom: '.5rem' }}>
                    {c.workLocation}
                  </div>
                  <div className="complaint-meta">
                    <span className="complaint-meta-item">👤 {c.isAnonymous ? 'Anonymous Worker' : (c.workerName || 'Unknown Worker')}</span>
                    <span className="complaint-meta-item">🏗️ {c.contractorName}</span>
                    {c.salaryAmount && <span className="complaint-meta-item">💰 ₹{c.salaryAmount?.toLocaleString()}</span>}
                    <span className="complaint-meta-item">📅 {formatDate(c.createdAt)}</span>
                    {c.typeOfProblem && <span className="complaint-meta-item">⚠️ {c.typeOfProblem.replace(/_/g, ' ')}</span>}
                  </div>
                  {c.assignedNGO && (
                    <div style={{ marginTop: '.5rem', fontSize: '.8rem', color: 'var(--success)', fontWeight: 600 }}>
                      ✓ Assigned to {c.assignedNGO.ngoName || 'your NGO'}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
