import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/common/ProtectedRoute';

// Pages
import HomePage from './pages/HomePage';
import WorkerLogin from './pages/worker/WorkerLogin';
import WorkerDashboard from './pages/worker/WorkerDashboard';
import RegisterComplaint from './pages/worker/RegisterComplaint';
import TrackComplaint from './pages/worker/TrackComplaint';
import NGOLogin from './pages/ngo/NGOLogin';
import NGORegister from './pages/ngo/NGORegister';
import NGODashboard from './pages/ngo/NGODashboard';
import NGOComplaintDetail from './pages/ngo/NGOComplaintDetail';
import NGOSubmitComplaint from './pages/ngo/NGOSubmitComplaint';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              borderRadius: '10px',
              fontFamily: 'Inter, sans-serif',
              fontWeight: 600,
              fontSize: '.9rem',
              boxShadow: '0 8px 32px rgba(0,0,0,.15)',
            },
            success: { iconTheme: { primary: '#16a34a', secondary: '#fff' } },
            error: { iconTheme: { primary: '#dc2626', secondary: '#fff' } },
          }}
        />
        <Routes>
          {/* Public */}
          <Route path="/" element={<HomePage />} />
          <Route path="/track" element={<TrackComplaint />} />

          {/* Worker */}
          <Route path="/worker/login" element={<WorkerLogin />} />
          <Route path="/worker/dashboard" element={<ProtectedRoute role="worker"><WorkerDashboard /></ProtectedRoute>} />
          <Route path="/worker/register-complaint" element={<ProtectedRoute role="worker"><RegisterComplaint /></ProtectedRoute>} />
          <Route path="/worker/track" element={<ProtectedRoute role="worker"><TrackComplaint /></ProtectedRoute>} />

          {/* NGO */}
          <Route path="/ngo/login" element={<NGOLogin />} />
          <Route path="/ngo/register" element={<NGORegister />} />
          <Route path="/ngo/dashboard" element={<ProtectedRoute role="ngo"><NGODashboard /></ProtectedRoute>} />
          <Route path="/ngo/complaint/:id" element={<ProtectedRoute role="ngo"><NGOComplaintDetail /></ProtectedRoute>} />
          <Route path="/ngo/submit-complaint" element={<ProtectedRoute role="ngo"><NGOSubmitComplaint /></ProtectedRoute>} />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
