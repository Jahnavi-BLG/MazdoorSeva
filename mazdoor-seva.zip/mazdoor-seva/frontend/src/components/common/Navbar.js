import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../utils/translations';

const languages = [
  { code: 'en', label: 'EN', name: 'English' },
  { code: 'hi', label: 'हि', name: 'हिंदी' },
  { code: 'te', label: 'తె', name: 'తెలుగు' },
];

export default function Navbar() {
  const { user, logout, language, changeLanguage } = useAuth();
  const { t } = useTranslation(language);
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="navbar-brand" style={{ cursor: 'pointer' }} onClick={() => navigate('/')}>
        <div className="logo-icon">⚒️</div>
        <div>
          <div>{t('appName')}</div>
          <div style={{ fontSize: '.65rem', fontWeight: 500, opacity: .7, letterSpacing: '.05em' }} className="tagline">{t('tagline')}</div>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '.5rem' }}>
        {/* Language switcher */}
        <div style={{ display: 'flex', gap: '.25rem', marginRight: '.5rem' }}>
          {languages.map(lang => (
            <button
              key={lang.code}
              onClick={() => changeLanguage(lang.code)}
              title={lang.name}
              style={{
                padding: '.3rem .6rem', border: 'none', borderRadius: 6,
                background: language === lang.code ? 'var(--primary)' : 'var(--gray-100)',
                color: language === lang.code ? '#fff' : 'var(--gray-600)',
                fontWeight: 700, fontSize: '.8rem', cursor: 'pointer',
                transition: 'all .15s',
              }}
            >
              {lang.label}
            </button>
          ))}
        </div>

        {user ? (
          <>
            {user.role === 'worker' && (
              <>
                <button className="nav-link" onClick={() => navigate('/worker/dashboard')}>
                  {t('dashboard')}
                </button>
                <button className="nav-link" onClick={() => navigate('/worker/register-complaint')}>
                  {t('registerComplaint')}
                </button>
                <button className="nav-link" onClick={() => navigate('/worker/track')}>
                  {t('trackComplaint')}
                </button>
              </>
            )}
            {user.role === 'ngo' && (
              <>
                <button className="nav-link" onClick={() => navigate('/ngo/dashboard')}>
                  {t('dashboard')}
                </button>
                <button className="nav-link" onClick={() => navigate('/ngo/submit-complaint')}>
                  {t('submitOnBehalf')}
                </button>
              </>
            )}
            <div style={{ display: 'flex', alignItems: 'center', gap: '.5rem', marginLeft: '.5rem', paddingLeft: '.5rem', borderLeft: '1px solid var(--gray-200)' }}>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '.8rem', fontWeight: 700, color: 'var(--gray-800)' }}>
                  {user.name || user.ngoName || user.phone}
                </div>
                <div style={{ fontSize: '.7rem', color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: '.05em' }}>
                  {user.role}
                </div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={handleLogout}>{t('logout')}</button>
            </div>
          </>
        ) : (
          <button className="btn btn-primary btn-sm" onClick={() => navigate('/')}>
            {t('home')}
          </button>
        )}
      </div>
    </nav>
  );
}
